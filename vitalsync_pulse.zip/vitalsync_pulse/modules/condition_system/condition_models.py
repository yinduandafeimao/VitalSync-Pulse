#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
条件数据模型模块

这个模块定义了条件系统使用的数据模型类，包括条件、条件参数和条件引用。
"""

import os
import json
import uuid
from datetime import datetime
from typing import List, Dict, Optional, Any, Union

# 从配置管理器导入
from vitalsync_pulse.core.config.config_manager import get_config

config_manager = get_config()

class ConditionParameter:
    """条件参数类
    
    表示条件的一个参数，包含名称、类型、值和描述等属性。
    
    属性:
        name (str): 参数名称
        param_type (str): 参数类型，如'int', 'float', 'str', 'bool', 'color', 'region'等
        value: 参数值，类型根据param_type而定
        description (str): 参数描述
        options (list): 参数可选值列表，仅当param_type为'select'时有效
    """
    
    def __init__(self, name: str, param_type: str, value: Any = None, description: str = "", options: List = None):
        """初始化条件参数
        
        参数:
            name (str): 参数名称
            param_type (str): 参数类型
            value: 参数值，默认为None
            description (str): 参数描述，默认为空字符串
            options (list): 参数可选值列表，默认为None
        """
        self.name = name
        self.param_type = param_type
        self.value = value
        self.description = description
        self.options = options or []
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典
        
        返回:
            Dict[str, Any]: 表示参数的字典
        """
        return {
            'name': self.name,
            'type': self.param_type,
            'value': self.value,
            'description': self.description,
            'options': self.options
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ConditionParameter':
        """从字典创建参数
        
        参数:
            data (Dict[str, Any]): 表示参数的字典
            
        返回:
            ConditionParameter: 创建的参数对象
        """
        return cls(
            name=data.get('name', ''),
            param_type=data.get('type', 'str'),
            value=data.get('value'),
            description=data.get('description', ''),
            options=data.get('options', [])
        )

class ConditionReference:
    """条件引用类
    
    表示对另一个条件的引用，用于组合条件。
    
    属性:
        condition_id (str): 被引用的条件ID
        operator (str): 与其他条件的关系运算符，如'and', 'or', 'not'
    """
    
    def __init__(self, condition_id: str, operator: str = 'and'):
        """初始化条件引用
        
        参数:
            condition_id (str): 被引用的条件ID
            operator (str): 与其他条件的关系运算符，默认为'and'
        """
        self.condition_id = condition_id
        self.operator = operator
    
    def to_dict(self) -> Dict[str, str]:
        """转换为字典
        
        返回:
            Dict[str, str]: 表示条件引用的字典
        """
        return {
            'condition_id': self.condition_id,
            'operator': self.operator
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, str]) -> 'ConditionReference':
        """从字典创建条件引用
        
        参数:
            data (Dict[str, str]): 表示条件引用的字典
            
        返回:
            ConditionReference: 创建的条件引用对象
        """
        return cls(
            condition_id=data.get('condition_id', ''),
            operator=data.get('operator', 'and')
        )

class Condition:
    """条件类
    
    表示一个触发条件，包含类型、参数和子条件等属性。
    
    属性:
        id (str): 条件唯一标识符
        name (str): 条件名称
        condition_type (str): 条件类型，如'color', 'text', 'time', 'combo'
        parameters (List[ConditionParameter]): 条件参数列表
        sub_conditions (List[ConditionReference]): 子条件引用列表
        enabled (bool): 是否启用
        description (str): 条件描述
        created_time (str): 创建时间
        last_modified (str): 最后修改时间
    """
    
    def __init__(self, name: str, condition_type: str, condition_id: str = None):
        """初始化条件
        
        参数:
            name (str): 条件名称
            condition_type (str): 条件类型
            condition_id (str): 条件ID，如果为None则自动生成
        """
        self.id = condition_id or str(uuid.uuid4())
        self.name = name
        self.condition_type = condition_type
        self.parameters: List[ConditionParameter] = []
        self.sub_conditions: List[ConditionReference] = []
        self.enabled = True
        self.description = ""
        self.created_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.last_modified = self.created_time
    
    def add_parameter(self, param: ConditionParameter) -> None:
        """添加参数
        
        参数:
            param (ConditionParameter): 要添加的参数
        """
        self.parameters.append(param)
        self.last_modified = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def add_sub_condition(self, sub_condition_id: str, operator: str = 'and') -> None:
        """添加子条件
        
        参数:
            sub_condition_id (str): 子条件ID
            operator (str): 与其他条件的关系运算符，默认为'and'
        """
        self.sub_conditions.append(ConditionReference(sub_condition_id, operator))
        self.last_modified = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def get_parameter(self, name: str) -> Optional[ConditionParameter]:
        """获取指定名称的参数
        
        参数:
            name (str): 参数名称
            
        返回:
            Optional[ConditionParameter]: 找到的参数，如果不存在则返回None
        """
        for param in self.parameters:
            if param.name == name:
                return param
        return None
    
    def get_parameter_value(self, name: str, default: Any = None) -> Any:
        """获取指定名称的参数值
        
        参数:
            name (str): 参数名称
            default: 默认值，如果参数不存在则返回此值
            
        返回:
            Any: 参数值或默认值
        """
        param = self.get_parameter(name)
        return param.value if param else default
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典
        
        返回:
            Dict[str, Any]: 表示条件的字典
        """
        return {
            'id': self.id,
            'name': self.name,
            'type': self.condition_type,
            'parameters': [p.to_dict() for p in self.parameters],
            'sub_conditions': [s.to_dict() for s in self.sub_conditions],
            'enabled': self.enabled,
            'description': self.description,
            'created_time': self.created_time,
            'last_modified': self.last_modified
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Condition':
        """从字典创建条件
        
        参数:
            data (Dict[str, Any]): 表示条件的字典
            
        返回:
            Condition: 创建的条件对象
        """
        condition = cls(
            name=data.get('name', ''),
            condition_type=data.get('type', ''),
            condition_id=data.get('id')
        )
        condition.enabled = data.get('enabled', True)
        condition.description = data.get('description', '')
        condition.created_time = data.get('created_time', condition.created_time)
        condition.last_modified = data.get('last_modified', condition.last_modified)
        
        # 加载参数
        for param_data in data.get('parameters', []):
            condition.parameters.append(ConditionParameter.from_dict(param_data))
        
        # 加载子条件
        for sub_data in data.get('sub_conditions', []):
            condition.sub_conditions.append(ConditionReference.from_dict(sub_data))
        
        return condition
    
    def save(self) -> bool:
        """保存条件到配置文件
        
        返回:
            bool: 是否保存成功
        """
        try:
            # 获取所有条件
            conditions = config_manager.get_json('conditions', {})
            
            # 更新当前条件
            conditions[self.id] = self.to_dict()
            
            # 保存到配置
            config_manager.set_json('conditions', conditions)
            config_manager.save_config()
            
            return True
        except Exception as e:
            print(f"保存条件失败: {str(e)}")
            return False
    
    @classmethod
    def load(cls, condition_id: str) -> Optional['Condition']:
        """从配置文件加载条件
        
        参数:
            condition_id (str): 条件ID
            
        返回:
            Optional[Condition]: 加载的条件，如果不存在则返回None
        """
        try:
            # 获取所有条件
            conditions = config_manager.get_json('conditions', {})
            
            # 获取指定ID的条件
            condition_data = conditions.get(condition_id)
            if not condition_data:
                return None
            
            return cls.from_dict(condition_data)
        except Exception as e:
            print(f"加载条件失败: {str(e)}")
            return None
    
    @classmethod
    def load_all(cls) -> Dict[str, 'Condition']:
        """加载所有条件
        
        返回:
            Dict[str, Condition]: 条件ID到条件对象的映射
        """
        result = {}
        try:
            # 获取所有条件
            conditions_data = config_manager.get_json('conditions', {})
            
            # 转换为条件对象
            for condition_id, condition_data in conditions_data.items():
                result[condition_id] = cls.from_dict(condition_data)
            
        except Exception as e:
            print(f"加载所有条件失败: {str(e)}")
        
        return result
    
    @classmethod
    def delete(cls, condition_id: str) -> bool:
        """删除条件
        
        参数:
            condition_id (str): 条件ID
            
        返回:
            bool: 是否删除成功
        """
        try:
            # 获取所有条件
            conditions = config_manager.get_json('conditions', {})
            
            # 如果条件存在，则删除
            if condition_id in conditions:
                del conditions[condition_id]
                
                # 保存到配置
                config_manager.set_json('conditions', conditions)
                config_manager.save_config()
                
                return True
            
            return False
        except Exception as e:
            print(f"删除条件失败: {str(e)}")
            return False

# 添加ConditionSystem类定义
class ConditionSystem:
    """
    条件系统
    
    这个类是条件系统的核心，用于管理条件数据库和运行时状态。
    它为应用程序控制器提供了一个统一的接口来操作条件系统。
    """
    
    def __init__(self):
        """初始化条件系统"""
        self.conditions = Condition.load_all()
        self.running = False
        self.active_conditions = set()  # 当前激活的条件ID集合
    
    def start(self):
        """启动条件系统"""
        self.running = True
        # 在这里添加启动逻辑，如开始条件检查循环等
        return True
    
    def stop(self):
        """停止条件系统"""
        self.running = False
        # 在这里添加停止逻辑
        return True
    
    def is_running(self):
        """检查条件系统是否正在运行"""
        return self.running
    
    def get_condition(self, condition_id):
        """获取条件"""
        return self.conditions.get(condition_id)
    
    def get_all_conditions(self):
        """获取所有条件"""
        return self.conditions
    
    def add_condition(self, condition):
        """添加条件"""
        self.conditions[condition.id] = condition
        return condition.save()
    
    def remove_condition(self, condition_id):
        """移除条件"""
        if condition_id in self.conditions:
            del self.conditions[condition_id]
            return Condition.delete(condition_id)
        return False
    
    def activate_condition(self, condition_id):
        """激活条件"""
        if condition_id in self.conditions:
            self.active_conditions.add(condition_id)
            return True
        return False
    
    def deactivate_condition(self, condition_id):
        """停用条件"""
        if condition_id in self.active_conditions:
            self.active_conditions.remove(condition_id)
            return True
        return False
    
    def is_condition_active(self, condition_id):
        """检查条件是否激活"""
        return condition_id in self.active_conditions
    
    def reload_conditions(self):
        """重新加载所有条件"""
        self.conditions = Condition.load_all()
        return True 