# 导入所需的库
import cv2
import numpy as np
import pyautogui
import keyboard
import time
import json
import os
import sys
import importlib.util
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QRect

# 导入项目内部模块
from vitalsync_pulse.ui.components.selection_box import FluentSelectionBox, show_selection_box, TransparentSelectionBox
from prettytable import PrettyTable  # 导入PrettyTable库用于美化输出

# TODO: 将来需要替换为项目内部模块
# 动态导入带空格的模块
module_name = "Zhu Xian World Health Bar Test(choice box)"
module_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), 
                          "Zhu Xian World Health Bar Test(choice box).py")
spec = importlib.util.spec_from_file_location(module_name, module_path)
health_bar_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(health_bar_module)

# 从模块中获取需要的函数
get_hp_percentage = health_bar_module.get_hp_percentage

class TeamMember:
    """小队成员类
    
    表示游戏中的一个小队成员，包含职业、血量和存活状态等属性。
    每个小队成员有自己的血条位置和颜色设置。
    
    属性:
        name (str): 成员名称
        profession (str): 职业名称
        health_percentage (float): 当前血量百分比
        is_alive (bool): 存活状态
        x1, y1 (int): 血条左上角坐标
        x2, y2 (int): 血条右下角坐标
        hp_color_lower (np.array): 血条颜色HSV下限
        hp_color_upper (np.array): 血条颜色HSV上限
    """
    
    def __init__(self, name, profession):
        """初始化小队成员
        
        参数:
            name (str): 成员名称
            profession (str): 职业名称
        """
        self.name = name
        self.profession = profession
        self.health_percentage = 100.0
        self.is_alive = True
        
        # 血条位置和颜色默认值
        self.x1 = 100
        self.y1 = 100
        self.x2 = 300
        self.y2 = 120
        self.hp_color_lower = np.array([43, 71, 121])
        self.hp_color_upper = np.array([63, 171, 221])
        
        # 配置文件路径
        self.config_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))),
                                     "config", "team_members")
        self.config_file = os.path.join(self.config_dir, f"{name}_config.json")
        
        # 确保配置文件目录存在
        os.makedirs(self.config_dir, exist_ok=True)
        
        # 尝试加载配置
        self.load_config()
    
    def load_config(self):
        """从配置文件加载设置
        
        从成员专属的配置文件中读取血条位置坐标和颜色范围的配置信息。
        如果配置文件不存在或读取出错，将使用默认设置。
        """
        try:
            if not os.path.exists(self.config_file):
                print(f"未找到{self.name}的配置文件，将使用默认设置并创建新的配置文件")
                self.save_config()
                return
                
            with open(self.config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
                
                # 验证配置文件的完整性
                if not all(key in config.get('health_bar', {}) for key in ['coordinates', 'color']):
                    raise ValueError("配置文件格式不正确")
                    
                coords = config['health_bar']['coordinates']
                if not all(key in coords for key in ['x1', 'y1', 'x2', 'y2']):
                    raise ValueError("坐标配置不完整")
                    
                color = config['health_bar']['color']
                if not all(key in color for key in ['lower', 'upper']):
                    raise ValueError("颜色配置不完整")
                
                # 更新配置
                self.x1 = coords['x1']
                self.y1 = coords['y1']
                self.x2 = coords['x2']
                self.y2 = coords['y2']
                self.hp_color_lower = np.array(color['lower'])
                self.hp_color_upper = np.array(color['upper'])
                
        except json.JSONDecodeError:
            print(f"解析{self.name}的配置文件时出错，文件格式不正确。使用默认设置")
            self.save_config()
        except ValueError as e:
            print(f"加载{self.name}的配置文件时出错: {str(e)}。使用默认设置")
            self.save_config()
        except Exception as e:
            print(f"加载{self.name}配置文件时出错: {str(e)}。使用默认设置")
            self.save_config()
    
    def save_config(self):
        """保存设置到配置文件
        
        将当前的血条位置坐标和颜色范围保存到成员专属的配置文件中。
        配置信息包括血条的坐标范围和HSV颜色范围。
        如果配置文件目录不存在，会自动创建。
        """
        config = {
            'profession': self.profession,  # 添加职业信息
            'health_bar': {
                'coordinates': {
                    'x1': self.x1,
                    'y1': self.y1,
                    'x2': self.x2,
                    'y2': self.y2
                },
                'color': {
                    'lower': self.hp_color_lower.tolist(),
                    'upper': self.hp_color_upper.tolist()
                }
            }
        }
        try:
            # 确保配置文件目录存在
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            
            # 使用临时文件来保存配置，以防写入过程中出错导致配置文件损坏
            temp_file = self.config_file + '.tmp'
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=4)
            
            # 如果写入成功，则替换原配置文件
            if os.path.exists(self.config_file):
                os.remove(self.config_file)
            os.rename(temp_file, self.config_file)
            
            print(f"{self.name}的设置已成功保存到配置文件")
        except PermissionError:
            print(f"保存{self.name}配置文件时出错: 没有写入权限")
        except OSError as e:
            print(f"保存{self.name}配置文件时出错: 文件系统错误 - {str(e)}")
        except Exception as e:
            print(f"保存{self.name}配置文件时出错: {str(e)}")
            # 如果临时文件存在，清理它
            if os.path.exists(temp_file):
                try:
                    os.remove(temp_file)
                except:
                    pass
    
    def set_health_bar_position(self):
        """设置血条位置
        
        通过选择框界面获取血条的起始和结束坐标。
        用户可以通过拖动鼠标来选择血条区域。
        """
        print(f"设置{self.name}的血条位置...")
        print("请使用鼠标拖动选择血条区域...")
        
        def on_selection(rect):
            self.x1 = rect.x()
            self.y1 = rect.y()
            self.x2 = rect.x() + rect.width()
            self.y2 = rect.y() + rect.height()
            print(f"{self.name}血条起始坐标设置为: ({self.x1}, {self.y1})")
            print(f"{self.name}血条结束坐标设置为: ({self.x2}, {self.y2})")
            self.save_config()  # 保存新的坐标设置
        
        # 显示选择框并等待用户操作
        result = show_selection_box(on_selection)
        
        # 根据用户操作返回不同的结果
        return result
    
    def set_health_bar_color(self):
        """设置血条颜色
        
        通过用户交互获取血条的颜色。
        用户需要将鼠标移动到血条上并按空格键确认。
        程序会获取该点的HSV颜色值，并设置一个合适的颜色范围用于后续的血条识别。
        """
        print(f"设置{self.name}的血条颜色...")
        print(f"请将鼠标移动到{self.name}血条颜色位置，按空格键获取颜色...")
        
        # 等待用户按下空格键
        keyboard.wait('space')
        
        # 获取当前鼠标位置
        x, y = pyautogui.position()
        
        try:
            # 截取鼠标位置附近的区域
            screenshot = pyautogui.screenshot(region=(x-5, y-5, 10, 10))
            screenshot_np = np.array(screenshot)
            screenshot_bgr = cv2.cvtColor(screenshot_np, cv2.COLOR_RGB2BGR)
            
            # 转换为HSV颜色空间
            hsv = cv2.cvtColor(screenshot_bgr, cv2.COLOR_BGR2HSV)
            
            # 获取中心点的HSV值
            center_hsv = hsv[5, 5]
            h, s, v = center_hsv
            
            # 设置HSV颜色范围，允许一定的误差
            h_margin = 10
            s_margin = 50
            v_margin = 50
            
            self.hp_color_lower = np.array([max(0, h - h_margin), max(0, s - s_margin), max(0, v - s_margin)])
            self.hp_color_upper = np.array([min(179, h + h_margin), min(255, s + s_margin), min(255, v + v_margin)])
            
            print(f"{self.name}血条颜色已设置:")
            print(f"HSV值: ({h}, {s}, {v})")
            print(f"颜色范围下限: {self.hp_color_lower}")
            print(f"颜色范围上限: {self.hp_color_upper}")
            
            # 保存新的颜色设置
            self.save_config()
            
            return True
        except Exception as e:
            print(f"设置{self.name}血条颜色时出错: {str(e)}")
            return False
    
    def update_health(self):
        """更新血量
        
        根据血条位置和颜色获取当前血量百分比。
        使用外部函数 get_hp_percentage 来计算血量。
        如果无法获取血量或血量为0，则将成员标记为死亡。
        
        返回:
            float: 当前血量百分比
        """
        try:
            # 检查坐标是否有效
            if self.x1 <= 0 or self.y1 <= 0 or self.x2 <= self.x1 or self.y2 <= self.y1:
                print(f"{self.name}的血条坐标无效，无法获取血量")
                return self.health_percentage
                
            # 获取血条区域截图
            width = self.x2 - self.x1
            height = self.y2 - self.y1
            screenshot = pyautogui.screenshot(region=(self.x1, self.y1, width, height))
            screenshot_np = np.array(screenshot)
            screenshot_bgr = cv2.cvtColor(screenshot_np, cv2.COLOR_RGB2BGR)
            
            # 计算血量百分比
            hp_percent = get_hp_percentage(screenshot_bgr, self.hp_color_lower, self.hp_color_upper)
            
            # 更新血量和存活状态
            self.health_percentage = hp_percent
            self.is_alive = hp_percent > 0
            
            return hp_percent
        except Exception as e:
            print(f"更新{self.name}血量时出错: {str(e)}")
            return self.health_percentage
    
    def __str__(self):
        """返回成员信息的字符串表示"""
        status = "存活" if self.is_alive else "阵亡"
        return f"{self.name} ({self.profession}): {self.health_percentage:.1f}% [{status}]"


class Team:
    """队伍类
    
    管理多个队友成员，提供队伍整体的操作和状态查询。
    
    属性:
        members (dict): 队友成员字典，键为成员名称，值为TeamMember对象
    """
    
    def __init__(self):
        """初始化队伍"""
        self.members = {}
        self.load_members()
    
    def load_members(self):
        """加载所有队友成员
        
        从配置文件目录中查找所有队友配置文件并加载。
        配置文件名格式为 "队友名称_config.json"。
        """
        # 配置文件目录
        config_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))),
                                "config", "team_members")
        
        # 确保目录存在
        if not os.path.exists(config_dir):
            os.makedirs(config_dir, exist_ok=True)
            print(f"创建队友配置目录: {config_dir}")
            return
        
        # 查找所有配置文件
        config_files = [f for f in os.listdir(config_dir) if f.endswith('_config.json')]
        
        if not config_files:
            print("未找到任何队友配置文件")
            return
            
        # 加载每个队友
        for config_file in config_files:
            try:
                # 从文件名提取队友名称
                member_name = config_file.replace('_config.json', '')
                
                # 从配置文件中读取职业信息
                file_path = os.path.join(config_dir, config_file)
                with open(file_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    profession = config.get('profession', '未知')
                
                # 创建队友对象并添加到队伍
                self.members[member_name] = TeamMember(member_name, profession)
                print(f"已加载队友: {member_name} ({profession})")
                
            except Exception as e:
                print(f"加载队友配置文件 {config_file} 时出错: {str(e)}")
    
    def add_member(self, name, profession):
        """添加新队友
        
        参数:
            name (str): 队友名称
            profession (str): 队友职业
            
        返回:
            TeamMember: 新添加的队友对象
        """
        if name in self.members:
            print(f"队友 {name} 已存在")
            return self.members[name]
            
        member = TeamMember(name, profession)
        self.members[name] = member
        print(f"已添加新队友: {name} ({profession})")
        return member
    
    def update_all_health(self):
        """更新所有队友的血量
        
        返回:
            dict: 队友名称和血量的字典
        """
        results = {}
        for name, member in self.members.items():
            hp = member.update_health()
            results[name] = hp
        return results
    
    def get_alive_members(self):
        """获取所有存活的队友
        
        返回:
            list: 存活队友的TeamMember对象列表
        """
        return [member for member in self.members.values() if member.is_alive]
    
    def get_dead_members(self):
        """获取所有阵亡的队友
        
        返回:
            list: 阵亡队友的TeamMember对象列表
        """
        return [member for member in self.members.values() if not member.is_alive]
    
    def show_config(self):
        """显示所有队友的配置信息
        
        以表格形式打印所有队友的配置信息，包括名称、职业、血条位置和颜色范围。
        """
        if not self.members:
            print("队伍中没有任何队友")
            return
            
        # 创建表格
        table = PrettyTable()
        table.field_names = ["队友名称", "职业", "血条位置", "颜色范围(HSV)"]
        
        # 添加队友信息
        for name, member in self.members.items():
            position = f"({member.x1}, {member.y1}) - ({member.x2}, {member.y2})"
            color_range = f"下限: {member.hp_color_lower}\n上限: {member.hp_color_upper}"
            table.add_row([name, member.profession, position, color_range])
        
        # 设置表格样式
        table.align = "l"  # 左对齐
        table.max_width["颜色范围(HSV)"] = 30
        
        # 打印表格
        print(table)
    
    def __str__(self):
        """返回队伍信息的字符串表示"""
        if not self.members:
            return "队伍中没有任何队友"
            
        # 创建表格
        table = PrettyTable()
        table.field_names = ["队友名称", "职业", "血量", "状态"]
        
        # 添加队友信息
        for name, member in self.members.items():
            status = "存活" if member.is_alive else "阵亡"
            table.add_row([name, member.profession, f"{member.health_percentage:.1f}%", status])
        
        # 设置表格样式
        table.align = "l"  # 左对齐
        
        # 获取表格字符串
        return str(table)


def main():
    """主函数，用于测试"""
    team = Team()
    
    # 显示队伍信息
    print("当前队伍配置:")
    team.show_config()
    
    # 更新所有队友血量
    print("\n更新队友血量...")
    team.update_all_health()
    
    # 显示队伍状态
    print("\n队伍状态:")
    print(team)
    
    # 添加新队友
    name = input("\n请输入新队友名称: ")
    profession = input("请输入新队友职业: ")
    new_member = team.add_member(name, profession)
    
    # 设置新队友的血条位置和颜色
    print("\n设置新队友血条位置...")
    new_member.set_health_bar_position()
    
    print("\n设置新队友血条颜色...")
    new_member.set_health_bar_color()
    
    # 显示更新后的队伍配置
    print("\n更新后的队伍配置:")
    team.show_config()


if __name__ == "__main__":
    main()

# 导出的类
__all__ = ['TeamMember', 'Team'] 