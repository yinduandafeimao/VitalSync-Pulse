"""
健康监控模块

该模块包含与游戏中队友血量监控相关的功能，包括：
- 队友管理
- 血条校准
- 队友识别
- 血量监控

主要组件：
- HealthMonitor: 血量监控器，负责实时监控队友血量
- HealthBarCalibration: 血条校准工具，用于设置血条位置
- TeammateRecognition: 队友识别工具，用于识别队友职业和名称
- TeamMember: 队友类，表示一个队友的数据结构
- Team: 队伍类，管理多个队友
"""

from .health_monitor import HealthMonitor, MonitorSignals
from .health_bar_calibration import HealthBarCalibration, CalibrationSignals
from .teammate_recognition import TeammateRecognition
from .team_member import TeamMember, Team

__all__ = [
    'HealthMonitor',
    'MonitorSignals',
    'HealthBarCalibration',
    'CalibrationSignals',
    'TeammateRecognition',
    'TeamMember',
    'Team'
] 