"""
队友识别模块

这个模块负责识别游戏中的队友信息，包括职业图标识别、队友名称识别和队友管理。
"""

# 将来会从子模块导入
# from vitalsync_pulse.modules.team_recognition.recognition import TeamRecognition
# from vitalsync_pulse.modules.team_recognition.team_members import Team, TeamMember 