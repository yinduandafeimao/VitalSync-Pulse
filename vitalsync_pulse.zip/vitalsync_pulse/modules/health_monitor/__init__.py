"""
血条监控模块

这个模块负责监控游戏中队友的血量状态，包括血条位置校准、血量计算和自动选择低血量队友。
"""

# 将来会从子模块导入
# from vitalsync_pulse.modules.health_monitor.health_monitor import HealthMonitor
# from vitalsync_pulse.modules.health_monitor.calibration import HealthBarCalibration 