"""
通用工具模块

这个模块包含了应用程序使用的通用工具函数，如键盘操作、图像处理等。
"""

# 将来会从子模块导入
# from vitalsync_pulse.core.utils.keyboard_utils import ...
# from vitalsync_pulse.core.utils.image_utils import ... 