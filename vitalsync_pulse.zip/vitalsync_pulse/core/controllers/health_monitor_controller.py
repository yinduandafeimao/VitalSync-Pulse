#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Health Monitor Controller

This module defines the controller for health monitoring functionality.
"""

from PyQt5.QtCore import pyqtSignal, QObject, Qt
from PyQt5.QtWidgets import QFrame, QVBoxLayout
from qfluentwidgets import InfoBar, InfoBarPosition, BodyLabel, StrongBodyLabel

from .base_controller import BaseController
from vitalsync_pulse.modules.health_monitoring import HealthMonitor, Team, TeamMember
from vitalsync_pulse.ui.views.health_monitor_view import HealthMonitorView


class HealthMonitorController(BaseController):
    """Health Monitor Controller class
    
    Responsible for coordinating interactions between the health monitoring view and model.
    
    Attributes:
        view: Health monitoring view
        model: Health monitoring model
    """
    
    def __init__(self, view=None, model=None):
        """Initialize health monitor controller
        
        Args:
            view: Health monitoring view
            model: Health monitoring model
        """
        # If no model is provided, create a new health monitoring model
        if model is None:
            # Create team object
            team = Team()
            # Create health monitor object
            model = HealthMonitor(team)
        
        super().__init__(view, model)
    
    def connect_view_model(self):
        """Connect view and model
        
        Establish signal and slot connections between the health monitoring view and model.
        """
        if not self.view or not self.model:
            return
        
        # Connect view button click events
        self.view.start_button.clicked.connect(self._on_start_clicked)
        self.view.stop_button.clicked.connect(self._on_stop_clicked)
        self.view.add_member_button.clicked.connect(self._on_add_member_clicked)
        
        # Connect model signals
        self.model.signals.status_signal.connect(self._on_status_changed)
        self.model.signals.update_signal.connect(self._on_health_data_updated)
    
    def disconnect_view_model(self):
        """Disconnect view and model
        
        Disconnect signal and slot connections between the health monitoring view and model.
        """
        if not self.view or not self.model:
            return
        
        # Disconnect view button click events
        self.view.start_button.clicked.disconnect(self._on_start_clicked)
        self.view.stop_button.clicked.disconnect(self._on_stop_clicked)
        self.view.add_member_button.clicked.disconnect(self._on_add_member_clicked)
        
        # Disconnect model signals
        self.model.signals.status_signal.disconnect(self._on_status_changed)
        self.model.signals.update_signal.disconnect(self._on_health_data_updated)
    
    def _on_start_clicked(self):
        """Start monitoring button click event handler"""
        if not self.model:
            return
        
        # Call model's start monitoring method
        success = self.model.start_monitoring()
        
        if success is not False:  # If start monitoring is successful
            # Update view state
            self.view.start_button.setEnabled(False)
            self.view.stop_button.setEnabled(True)
            self.view.status_label.setText("Running")
            self.view.status_label.setStyleSheet("color: green;")
            
            # Show info bar
            InfoBar.success(
                title="Monitoring Started",
                content="Health monitoring feature has been successfully started",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
    
    def _on_stop_clicked(self):
        """Stop monitoring button click event handler"""
        if not self.model:
            return
        
        # Call model's stop monitoring method
        self.model.stop_monitoring()
        
        # Update view state
        self.view.start_button.setEnabled(True)
        self.view.stop_button.setEnabled(False)
        self.view.status_label.setText("Not Running")
        self.view.status_label.setStyleSheet("color: gray;")
        
        # Show info bar
        InfoBar.information(
            title="Monitoring Stopped",
            content="Health monitoring feature has been stopped",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_add_member_clicked(self):
        """Add member button click event handler"""
        if not self.model:
            return
        
        # Call model's add team member method
        self.model.add_team_member()
        
        # Refresh team members display
        self._update_team_members_display()
    
    def _on_status_changed(self, status):
        """Status change event handler
        
        Args:
            status: New status information
        """
        # Update status display in view
        if self.view:
            self.view.status_label.setText(status)
            
            # Emit status changed signal
            self.status_changed.emit(status)
    
    def _on_health_data_updated(self, health_data):
        """Health data update event handler
        
        Args:
            health_data: Updated health data in format [(name, health_percentage, is_alive), ...]
        """
        # Update health data display in view
        if self.view:
            # Implement health data update logic in view
            self._update_health_display(health_data)
    
    def _update_team_members_display(self):
        """Update team members display"""
        if not self.view or not self.model or not self.model.team:
            return
        
        # Clear team members grid
        # First, remove old team members display
        for i in reversed(range(self.view.team_grid.count())):
            item = self.view.team_grid.itemAt(i)
            if item.widget():
                item.widget().deleteLater()
        
        # If no team members, show placeholder text
        if not self.model.team.members:
            placeholder = BodyLabel("No team members yet. Click 'Add Member' button to add one.")
            placeholder.setAlignment(Qt.AlignCenter)
            self.view.team_grid.addWidget(placeholder, 0, 0)
            return
        
        # Add team members
        for i, member in enumerate(self.model.team.members):
            row = i // 2
            col = i % 2
            
            # Create team member card
            member_frame = QFrame()
            member_frame.setStyleSheet("background-color: #f0f0f0; border-radius: 5px; padding: 5px;")
            member_layout = QVBoxLayout(member_frame)
            
            # Member name
            name_label = StrongBodyLabel(member.name)
            member_layout.addWidget(name_label)
            
            # Member profession
            role_label = BodyLabel(f"Role: {member.profession or 'Not set'}")
            member_layout.addWidget(role_label)
            
            # Member health (initially unknown)
            health_label = BodyLabel("Health: Unknown")
            health_label.setObjectName(f"health_label_{member.name}")
            member_layout.addWidget(health_label)
            
            # Add to grid
            self.view.team_grid.addWidget(member_frame, row, col)
    
    def _update_health_display(self, health_data):
        """Update health data display
        
        Args:
            health_data: Health data in format [(name, health_percentage, is_alive), ...]
        """
        if not self.view:
            return
        
        # Update health display for each member
        for name, hp, is_alive in health_data:
            # Find corresponding health label
            health_label = self.view.findChild(QObject, f"health_label_{name}")
            if health_label:
                if is_alive:
                    # Set health text and color
                    health_label.setText(f"Health: {hp:.1f}%")
                    
                    # Set color based on health
                    if hp < 30:
                        health_label.setStyleSheet("color: red;")
                    elif hp < 50:
                        health_label.setStyleSheet("color: orange;")
                    else:
                        health_label.setStyleSheet("color: green;")
                else:
                    # If not alive, show dead status
                    health_label.setText("Health: Dead")
                    health_label.setStyleSheet("color: gray;")
    
    def add_demo_team_members(self):
        """Add demo team members"""
        if not self.model or not self.model.team:
            return
        
        # Create demo team members
        member1 = TeamMember("Player1", "Warrior")
        member2 = TeamMember("Player2", "Mage")
        member3 = TeamMember("Player3", "Priest")
        member4 = TeamMember("Player4", "Hunter")
        
        # Manually set health bar positions (demo fixed values)
        member1.x1, member1.y1, member1.x2, member1.y2 = 100, 100, 300, 120
        member2.x1, member2.y1, member2.x2, member2.y2 = 100, 130, 300, 150
        member3.x1, member3.y1, member3.x2, member3.y2 = 100, 160, 300, 180
        member4.x1, member4.y1, member4.x2, member4.y2 = 100, 190, 300, 210
        
        # Add to team
        self.model.team.add_member(member1)
        self.model.team.add_member(member2)
        self.model.team.add_member(member3)
        self.model.team.add_member(member4)
        
        # Update team members display
        self._update_team_members_display()
        
        # Show info bar
        if self.view:
            InfoBar.success(
                title="Demo Team Members Added",
                content="Added 4 demo team members. You can start monitoring test.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            ) 