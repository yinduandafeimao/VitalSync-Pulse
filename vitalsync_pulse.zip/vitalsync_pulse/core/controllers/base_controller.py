#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
基础控制器

这个模块定义了基础控制器类，所有其他控制器都应该继承自这个类。
"""

from PyQt5.QtCore import QObject, pyqtSignal

class BaseController(QObject):
    """基础控制器类
    
    所有控制器的基类，提供基本功能和接口。
    
    属性:
        view: 关联的视图
        model: 关联的模型
    """
    
    # 定义通用信号
    status_changed = pyqtSignal(str)  # 状态变化信号
    
    def __init__(self, view=None, model=None):
        """初始化控制器
        
        参数:
            view: 关联的视图
            model: 关联的模型
        """
        super().__init__()
        self.view = view
        self.model = model
        
        # 如果提供了视图和模型，则建立连接
        if view and model:
            self.connect_view_model()
    
    def set_view(self, view):
        """设置视图
        
        参数:
            view: 关联的视图
        """
        self.view = view
        
        # 如果模型也已设置，则建立连接
        if self.model:
            self.connect_view_model()
    
    def set_model(self, model):
        """设置模型
        
        参数:
            model: 关联的模型
        """
        self.model = model
        
        # 如果视图也已设置，则建立连接
        if self.view:
            self.connect_view_model()
    
    def connect_view_model(self):
        """连接视图和模型
        
        建立视图和模型之间的信号和槽连接。
        子类应该重写此方法以实现特定的连接逻辑。
        """
        pass
    
    def disconnect_view_model(self):
        """断开视图和模型的连接
        
        断开视图和模型之间的信号和槽连接。
        子类应该重写此方法以实现特定的断开逻辑。
        """
        pass
    
    def cleanup(self):
        """清理资源
        
        释放控制器使用的资源。
        子类应该重写此方法以实现特定的清理逻辑。
        """
        self.disconnect_view_model()
        self.view = None
        self.model = None 