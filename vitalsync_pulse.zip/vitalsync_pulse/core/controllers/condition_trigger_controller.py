#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Condition Trigger Controller

This module defines the controller for condition trigger functionality.
"""

from PyQt5.QtCore import pyqtSignal, QObject, Qt
from PyQt5.QtWidgets import QTableWidgetItem, QListWidgetItem
from PyQt5.QtGui import QColor
from qfluentwidgets import InfoBar, InfoBarPosition, FluentIcon as FIF
from uuid import uuid4
import time
from datetime import datetime

from .base_controller import BaseController
from vitalsync_pulse.modules.condition_system.condition_models import (
    Condition, ConditionParameter, ConditionReference
)
from vitalsync_pulse.ui.views.condition_trigger_view import ConditionTriggerView


class ConditionTriggerController(BaseController):
    """Condition Trigger Controller class
    
    Responsible for coordinating interactions between the condition trigger view and model.
    
    Attributes:
        view: Condition trigger view
        model: Condition system model manager
        monitoring_active: Flag indicating if condition monitoring is active
        monitor_timer: Timer for condition monitoring
    """
    
    def __init__(self, view=None, model=None):
        """Initialize condition trigger controller
        
        Args:
            view: Condition trigger view
            model: Condition system model
        """
        super().__init__(view, model)
        
        # Current selected condition for editing
        self.current_condition = None
        
        # Current selected composite condition
        self.current_composite = None
        
        # Monitoring state
        self.monitoring_active = False
        self.monitoring_results = {}  # condition_id -> (result, last_check_time)
    
    def connect_view_model(self):
        """Connect view and model
        
        Establish signal and slot connections between the condition trigger view and model.
        """
        if not self.view or not self.model:
            return
        
        # Connect tab widget signals
        self.view.tab_widget.currentChanged.connect(self._on_tab_changed)
        
        # Connect conditions tab signals
        self.view.add_color_condition_btn.clicked.connect(self._on_add_color_condition)
        self.view.add_text_condition_btn.clicked.connect(self._on_add_text_condition)
        self.view.add_time_condition_btn.clicked.connect(self._on_add_time_condition)
        
        # Connect composite tab signals
        self.view.add_composite_button.clicked.connect(self._on_add_composite_clicked)
        self.view.composite_list.currentItemChanged.connect(self._on_composite_selected)
        
        # Connect monitor tab signals
        self.view.start_monitor_button.clicked.connect(self._on_start_monitor_clicked)
        self.view.stop_monitor_button.clicked.connect(self._on_stop_monitor_clicked)
        
        # Load initial data
        self._load_conditions()
        self._load_composites()
    
    def disconnect_view_model(self):
        """Disconnect view and model
        
        Disconnect signal and slot connections between the condition trigger view and model.
        """
        if not self.view or not self.model:
            return
        
        # Disconnect tab widget signals
        self.view.tab_widget.currentChanged.disconnect(self._on_tab_changed)
        
        # Disconnect conditions tab signals
        self.view.add_color_condition_btn.clicked.disconnect(self._on_add_color_condition)
        self.view.add_text_condition_btn.clicked.disconnect(self._on_add_text_condition)
        self.view.add_time_condition_btn.clicked.disconnect(self._on_add_time_condition)
        
        # Disconnect composite tab signals
        self.view.add_composite_button.clicked.disconnect(self._on_add_composite_clicked)
        self.view.composite_list.currentItemChanged.disconnect(self._on_composite_selected)
        
        # Disconnect monitor tab signals
        self.view.start_monitor_button.clicked.disconnect(self._on_start_monitor_clicked)
        self.view.stop_monitor_button.clicked.disconnect(self._on_stop_monitor_clicked)
        
        # Stop monitoring if active
        if self.monitoring_active:
            self._stop_monitoring()
    
    def _load_conditions(self):
        """Load conditions from model to view"""
        if not self.view or not self.model:
            return
        
        # Clear the condition table
        self.view.condition_table.setRowCount(0)
        
        # Get all conditions
        conditions = Condition.load_all()
        
        # Add each condition to the table
        for i, (condition_id, condition) in enumerate(conditions.items()):
            self.view.condition_table.insertRow(i)
            
            # Name
            name_item = QTableWidgetItem(condition.name)
            name_item.setData(Qt.UserRole, condition_id)
            self.view.condition_table.setItem(i, 0, name_item)
            
            # Type
            type_item = QTableWidgetItem(self._get_condition_type_display(condition.condition_type))
            self.view.condition_table.setItem(i, 1, type_item)
            
            # Status
            status_item = QTableWidgetItem()
            status_item.setCheckState(Qt.Checked if condition.enabled else Qt.Unchecked)
            self.view.condition_table.setItem(i, 2, status_item)
            
            # Last trigger
            last_trigger_item = QTableWidgetItem("Not triggered")
            self.view.condition_table.setItem(i, 3, last_trigger_item)
            
            # Add operation buttons in cell widget from view
            # (This is already set up in the view's setup_conditions_tab method)
    
    def _load_composites(self):
        """Load composite conditions from model to view"""
        if not self.view or not self.model:
            return
        
        # Clear the composite list
        self.view.composite_list.clear()
        
        # Get all conditions
        conditions = Condition.load_all()
        
        # Filter composite conditions
        composites = {cid: condition for cid, condition in conditions.items() 
                     if condition.condition_type == 'combo'}
        
        # Add each composite to the list
        for condition_id, condition in composites.items():
            item = QListWidgetItem(condition.name)
            item.setIcon(FIF.FLAG)
            item.setData(Qt.UserRole, condition_id)
            self.view.composite_list.addItem(item)
    
    def _get_condition_type_display(self, condition_type):
        """Get display name for condition type
        
        Args:
            condition_type: Internal condition type
            
        Returns:
            Display name for the condition type
        """
        type_mapping = {
            'color': 'Color Condition',
            'text': 'Text Condition',
            'time': 'Time Condition',
            'combo': 'Composite Condition'
        }
        return type_mapping.get(condition_type, condition_type)
    
    def _on_tab_changed(self, index):
        """Handle tab change event
        
        Args:
            index: Index of the selected tab
        """
        # Refresh data when switching to a tab
        if index == 0:  # Conditions list tab
            self._load_conditions()
        elif index == 1:  # Composite conditions tab
            self._load_composites()
        elif index == 2:  # Monitor tab
            # Update monitoring status display
            self._update_monitor_status()
    
    def _on_add_color_condition(self):
        """Handle add color condition button click"""
        # Create a new color condition
        condition = Condition("New Color Condition", "color")
        
        # Add default parameters
        condition.add_parameter(ConditionParameter("region", "region", {"x1": 0, "y1": 0, "x2": 100, "y2": 100}))
        condition.add_parameter(ConditionParameter("color", "color", [255, 0, 0]))
        condition.add_parameter(ConditionParameter("tolerance", "int", 20))
        
        # Save condition
        condition.save()
        
        # Refresh conditions list
        self._load_conditions()
        
        # Show success message
        InfoBar.success(
            title="Condition Added",
            content="New color condition has been added.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_add_text_condition(self):
        """Handle add text condition button click"""
        # Create a new text condition
        condition = Condition("New Text Condition", "text")
        
        # Add default parameters
        condition.add_parameter(ConditionParameter("region", "region", {"x1": 0, "y1": 0, "x2": 200, "y2": 50}))
        condition.add_parameter(ConditionParameter("text", "str", "Sample Text"))
        condition.add_parameter(ConditionParameter("case_sensitive", "bool", False))
        
        # Save condition
        condition.save()
        
        # Refresh conditions list
        self._load_conditions()
        
        # Show success message
        InfoBar.success(
            title="Condition Added",
            content="New text condition has been added.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_add_time_condition(self):
        """Handle add time condition button click"""
        # Create a new time condition
        condition = Condition("New Time Condition", "time")
        
        # Add default parameters
        condition.add_parameter(ConditionParameter("interval", "float", 60.0))
        condition.add_parameter(ConditionParameter("start_time", "str", ""))
        condition.add_parameter(ConditionParameter("end_time", "str", ""))
        
        # Save condition
        condition.save()
        
        # Refresh conditions list
        self._load_conditions()
        
        # Show success message
        InfoBar.success(
            title="Condition Added",
            content="New time condition has been added.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_add_composite_clicked(self):
        """Handle add composite condition button click"""
        # Create a new composite condition
        condition = Condition("New Composite Condition", "combo")
        
        # Add default parameters
        condition.add_parameter(ConditionParameter("operator", "str", "AND"))
        
        # Save condition
        condition.save()
        
        # Refresh composites list
        self._load_composites()
        
        # Select the new condition
        for i in range(self.view.composite_list.count()):
            item = self.view.composite_list.item(i)
            if item.data(Qt.UserRole) == condition.id:
                self.view.composite_list.setCurrentItem(item)
                break
        
        # Show success message
        InfoBar.success(
            title="Composite Added",
            content="New composite condition has been added. Add sub-conditions to it.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_composite_selected(self, current, previous):
        """Handle composite condition selection change
        
        Args:
            current: Currently selected item
            previous: Previously selected item
        """
        if not current:
            self.current_composite = None
            return
        
        # Get condition ID from item data
        condition_id = current.data(Qt.UserRole)
        
        # Load condition
        condition = Condition.load(condition_id)
        if not condition:
            InfoBar.error(
                title="Condition Not Found",
                content=f"Composite condition with ID {condition_id} not found.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
            return
        
        # Set current composite
        self.current_composite = condition
        
        # Update form with condition details
        self.view.composite_name_edit.setText(condition.name)
        
        # Set operator type
        operator_param = condition.get_parameter("operator")
        if operator_param and operator_param.value == "OR":
            self.view.composite_type_combo.setCurrentIndex(1)
        else:
            self.view.composite_type_combo.setCurrentIndex(0)
        
        # Clear conditions flow layout
        while self.view.conditions_flow_layout.count():
            item = self.view.conditions_flow_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # Add sub-conditions to flow layout
        all_conditions = Condition.load_all()
        for sub_ref in condition.sub_conditions:
            if sub_ref.condition_id in all_conditions:
                sub_condition = all_conditions[sub_ref.condition_id]
                condition_label = self.view._create_condition_label(sub_condition.name)
                self.view.conditions_flow_layout.addWidget(condition_label)
    
    def _on_start_monitor_clicked(self):
        """Handle start monitoring button click"""
        if self.monitoring_active:
            return
        
        # Start monitoring
        self.monitoring_active = True
        
        # Update UI
        self.view.start_monitor_button.setEnabled(False)
        self.view.stop_monitor_button.setEnabled(True)
        self.view.monitor_status_label.setText("Monitoring Active")
        self.view.monitor_status_label.setStyleSheet("color: green;")
        
        # Initialize monitoring results table
        self._initialize_monitoring_table()
        
        # Start monitor timer if not already
        self._start_monitoring()
        
        # Show success message
        InfoBar.success(
            title="Monitoring Started",
            content="Condition monitoring has been started.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_stop_monitor_clicked(self):
        """Handle stop monitoring button click"""
        if not self.monitoring_active:
            return
        
        # Stop monitoring
        self.monitoring_active = False
        
        # Update UI
        self.view.start_monitor_button.setEnabled(True)
        self.view.stop_monitor_button.setEnabled(False)
        self.view.monitor_status_label.setText("Monitoring Inactive")
        self.view.monitor_status_label.setStyleSheet("color: gray;")
        
        # Stop monitor timer
        self._stop_monitoring()
        
        # Show info message
        InfoBar.information(
            title="Monitoring Stopped",
            content="Condition monitoring has been stopped.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _initialize_monitoring_table(self):
        """Initialize monitoring results table"""
        # Clear the table
        self.view.monitoring_table.setRowCount(0)
        
        # Get all conditions
        conditions = Condition.load_all()
        
        # Add each condition to the table
        row = 0
        for condition_id, condition in conditions.items():
            if condition.enabled:
                self.view.monitoring_table.insertRow(row)
                
                # Name
                name_item = QTableWidgetItem(condition.name)
                name_item.setData(Qt.UserRole, condition_id)
                self.view.monitoring_table.setItem(row, 0, name_item)
                
                # Type
                type_item = QTableWidgetItem(self._get_condition_type_display(condition.condition_type))
                self.view.monitoring_table.setItem(row, 1, type_item)
                
                # Status
                status_item = QTableWidgetItem("Pending")
                status_item.setBackground(QColor(240, 240, 240))
                self.view.monitoring_table.setItem(row, 2, status_item)
                
                # Last check
                last_check_item = QTableWidgetItem("Not checked yet")
                self.view.monitoring_table.setItem(row, 3, last_check_item)
                
                row += 1
    
    def _update_monitor_status(self):
        """Update monitoring status display"""
        if self.monitoring_active:
            self.view.monitor_status_label.setText("Monitoring Active")
            self.view.monitor_status_label.setStyleSheet("color: green;")
            self.view.start_monitor_button.setEnabled(False)
            self.view.stop_monitor_button.setEnabled(True)
        else:
            self.view.monitor_status_label.setText("Monitoring Inactive")
            self.view.monitor_status_label.setStyleSheet("color: gray;")
            self.view.start_monitor_button.setEnabled(True)
            self.view.stop_monitor_button.setEnabled(False)
    
    def _start_monitoring(self):
        """Start condition monitoring"""
        # In a real implementation, this would set up a timer to check conditions
        # For this example, we'll simulate it with a simple timer
        
        # TODO: Implement actual monitoring using timer and condition evaluation
        # This would involve:
        # 1. Setting up a QTimer to check conditions at regular intervals
        # 2. Evaluating each condition based on its type
        # 3. Updating the monitoring results table with the results
        pass
    
    def _stop_monitoring(self):
        """Stop condition monitoring"""
        # TODO: Implement stopping the monitoring timer
        pass
    
    def edit_condition(self, condition_id):
        """Edit a condition
        
        Args:
            condition_id: ID of the condition to edit
        """
        # Load condition
        condition = Condition.load(condition_id)
        if not condition:
            InfoBar.error(
                title="Condition Not Found",
                content=f"Condition with ID {condition_id} not found.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
            return
        
        # Set current condition
        self.current_condition = condition
        
        # TODO: Open condition edit dialog
        # For this example, we'll just show an info message
        InfoBar.information(
            title="Edit Condition",
            content=f"Editing condition: {condition.name}",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def delete_condition(self, condition_id):
        """Delete a condition
        
        Args:
            condition_id: ID of the condition to delete
        """
        # Delete condition
        success = Condition.delete(condition_id)
        
        if success:
            # Refresh conditions list
            self._load_conditions()
            
            # Refresh composites list
            self._load_composites()
            
            # Show success message
            InfoBar.success(
                title="Condition Deleted",
                content="Condition has been deleted.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
        else:
            # Show error message
            InfoBar.error(
                title="Delete Failed",
                content=f"Failed to delete condition with ID {condition_id}.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            ) 