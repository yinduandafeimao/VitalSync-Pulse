#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Skill Cycle Controller

This module defines the controller for skill cycle functionality.
"""

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QListWidgetItem
from qfluentwidgets import InfoBar, InfoBarPosition, FluentIcon as FIF

from .base_controller import BaseController
from vitalsync_pulse.modules.skill_system.skill_models import Skill, SkillCycle
from vitalsync_pulse.modules.skill_system.advanced_skills import AdvancedSkill
from vitalsync_pulse.ui.views.skill_cycle_view import SkillCycleView


class SkillCycleController(BaseController):
    """Skill Cycle Controller class
    
    Responsible for coordinating interactions between the skill cycle view and model.
    
    Attributes:
        view: Skill cycle view
        model: Skill system model manager
        current_skill: The currently selected skill
        current_cycle: The currently selected skill cycle
    """
    
    def __init__(self, view=None, model=None):
        """Initialize skill cycle controller
        
        Args:
            view: Skill cycle view
            model: Skill system model
        """
        super().__init__(view, model)
        
        # Current selected skill for editing
        self.current_skill = None
        
        # Current selected skill cycle
        self.current_cycle = None
    
    def connect_view_model(self):
        """Connect view and model
        
        Establish signal and slot connections between the skill cycle view and model.
        """
        if not self.view or not self.model:
            return
        
        # Connect skill list signals
        self.view.skill_list.currentItemChanged.connect(self._on_skill_selected)
        
        # Connect button signals
        self.view.add_skill_button.clicked.connect(self._on_add_skill)
        self.view.save_skill_button.clicked.connect(self._on_save_skill)
        self.view.delete_skill_button.clicked.connect(self._on_delete_skill)
        
        # Connect cycle tab signals
        self.view.add_cycle_button.clicked.connect(self._on_add_cycle)
        self.view.save_cycle_button.clicked.connect(self._on_save_cycle)
        self.view.delete_cycle_button.clicked.connect(self._on_delete_cycle)
        self.view.cycle_list.currentItemChanged.connect(self._on_cycle_selected)
        
        # Load initial data
        self._load_skills()
        self._load_cycles()
    
    def disconnect_view_model(self):
        """Disconnect view and model
        
        Disconnect signal and slot connections between the skill cycle view and model.
        """
        if not self.view or not self.model:
            return
        
        # Disconnect skill list signals
        self.view.skill_list.currentItemChanged.disconnect(self._on_skill_selected)
        
        # Disconnect button signals
        self.view.add_skill_button.clicked.disconnect(self._on_add_skill)
        self.view.save_skill_button.clicked.disconnect(self._on_save_skill)
        self.view.delete_skill_button.clicked.disconnect(self._on_delete_skill)
        
        # Disconnect cycle tab signals
        self.view.add_cycle_button.clicked.disconnect(self._on_add_cycle)
        self.view.save_cycle_button.clicked.disconnect(self._on_save_cycle)
        self.view.delete_cycle_button.clicked.disconnect(self._on_delete_cycle)
        self.view.cycle_list.currentItemChanged.disconnect(self._on_cycle_selected)
    
    def _load_skills(self):
        """Load skills from model to view"""
        if not self.view or not self.model:
            return
        
        # Clear the skill list
        self.view.skill_list.clear()
        
        # Get all skills
        skills = Skill.load_all()
        
        # Add each skill to the list
        for skill_id, skill in skills.items():
            item = QListWidgetItem(skill.name)
            item.setData(Qt.UserRole, skill_id)
            
            # Set icon based on skill type
            if isinstance(skill, AdvancedSkill):
                item.setIcon(FIF.DIAMOND)
            else:
                item.setIcon(FIF.CALIBRATE)
                
            self.view.skill_list.addItem(item)
    
    def _load_cycles(self):
        """Load skill cycles from model to view"""
        if not self.view or not self.model:
            return
        
        # Clear the cycle list
        self.view.cycle_list.clear()
        
        # Get all cycles
        cycles = SkillCycle.load_all()
        
        # Add each cycle to the list
        for cycle_id, cycle in cycles.items():
            item = QListWidgetItem(cycle.name)
            item.setData(Qt.UserRole, cycle_id)
            item.setIcon(FIF.CYCLIC)
            self.view.cycle_list.addItem(item)
    
    def _on_skill_selected(self, current, previous):
        """Handle skill selection change
        
        Args:
            current: Currently selected item
            previous: Previously selected item
        """
        if not current:
            self.current_skill = None
            self._clear_skill_form()
            return
        
        # Get skill ID from item data
        skill_id = current.data(Qt.UserRole)
        
        # Load skill
        skill = Skill.load(skill_id)
        if not skill:
            InfoBar.error(
                title="Skill Not Found",
                content=f"Skill with ID {skill_id} not found.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
            return
        
        # Set current skill
        self.current_skill = skill
        
        # Update form with skill details
        self._populate_skill_form(skill)
    
    def _on_add_skill(self):
        """Handle add skill button click"""
        # Create a new skill
        skill = Skill("New Skill", "Basic skill description")
        
        # Set default properties
        skill.hotkey = ""
        skill.cooldown = 0
        skill.duration = 0
        
        # Save skill
        skill.save()
        
        # Refresh skills list
        self._load_skills()
        
        # Select the new skill
        for i in range(self.view.skill_list.count()):
            item = self.view.skill_list.item(i)
            if item.data(Qt.UserRole) == skill.id:
                self.view.skill_list.setCurrentItem(item)
                break
        
        # Show success message
        InfoBar.success(
            title="Skill Added",
            content="New skill has been added.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_save_skill(self):
        """Handle save skill button click"""
        if not self.current_skill:
            InfoBar.warning(
                title="No Skill Selected",
                content="Please select a skill to save.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
            return
        
        # Update skill with form data
        self.current_skill.name = self.view.skill_name_edit.text()
        self.current_skill.description = self.view.skill_description_edit.toPlainText()
        self.current_skill.hotkey = self.view.skill_hotkey_edit.text()
        
        try:
            self.current_skill.cooldown = float(self.view.skill_cooldown_edit.text())
            self.current_skill.duration = float(self.view.skill_duration_edit.text())
        except ValueError:
            InfoBar.error(
                title="Invalid Input",
                content="Cooldown and duration must be valid numbers.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
            return
        
        # Save skill
        self.current_skill.save()
        
        # Refresh skills list to update the display
        self._load_skills()
        
        # Show success message
        InfoBar.success(
            title="Skill Saved",
            content=f"Skill '{self.current_skill.name}' has been saved.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_delete_skill(self):
        """Handle delete skill button click"""
        if not self.current_skill:
            InfoBar.warning(
                title="No Skill Selected",
                content="Please select a skill to delete.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
            return
        
        # Delete skill
        success = Skill.delete(self.current_skill.id)
        
        if success:
            # Refresh skills list
            self._load_skills()
            
            # Clear skill form
            self._clear_skill_form()
            
            # Reset current skill
            self.current_skill = None
            
            # Show success message
            InfoBar.success(
                title="Skill Deleted",
                content="Skill has been deleted.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
        else:
            # Show error message
            InfoBar.error(
                title="Delete Failed",
                content=f"Failed to delete skill with ID {self.current_skill.id}.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
    
    def _clear_skill_form(self):
        """Clear skill form fields"""
        self.view.skill_name_edit.setText("")
        self.view.skill_description_edit.setPlainText("")
        self.view.skill_hotkey_edit.setText("")
        self.view.skill_cooldown_edit.setText("0")
        self.view.skill_duration_edit.setText("0")
    
    def _populate_skill_form(self, skill):
        """Populate skill form with data
        
        Args:
            skill: Skill to display in the form
        """
        self.view.skill_name_edit.setText(skill.name)
        self.view.skill_description_edit.setPlainText(skill.description)
        self.view.skill_hotkey_edit.setText(skill.hotkey)
        self.view.skill_cooldown_edit.setText(str(skill.cooldown))
        self.view.skill_duration_edit.setText(str(skill.duration))
    
    def _on_cycle_selected(self, current, previous):
        """Handle cycle selection change
        
        Args:
            current: Currently selected item
            previous: Previously selected item
        """
        if not current:
            self.current_cycle = None
            self._clear_cycle_form()
            return
        
        # Get cycle ID from item data
        cycle_id = current.data(Qt.UserRole)
        
        # Load cycle
        cycle = SkillCycle.load(cycle_id)
        if not cycle:
            InfoBar.error(
                title="Cycle Not Found",
                content=f"Skill cycle with ID {cycle_id} not found.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
            return
        
        # Set current cycle
        self.current_cycle = cycle
        
        # Update form with cycle details
        self._populate_cycle_form(cycle)
    
    def _on_add_cycle(self):
        """Handle add cycle button click"""
        # Create a new skill cycle
        cycle = SkillCycle("New Skill Cycle", "Basic cycle description")
        
        # Set default properties
        cycle.trigger_key = ""
        cycle.activation_condition = ""
        cycle.enabled = False
        
        # Save cycle
        cycle.save()
        
        # Refresh cycles list
        self._load_cycles()
        
        # Select the new cycle
        for i in range(self.view.cycle_list.count()):
            item = self.view.cycle_list.item(i)
            if item.data(Qt.UserRole) == cycle.id:
                self.view.cycle_list.setCurrentItem(item)
                break
        
        # Show success message
        InfoBar.success(
            title="Cycle Added",
            content="New skill cycle has been added.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_save_cycle(self):
        """Handle save cycle button click"""
        if not self.current_cycle:
            InfoBar.warning(
                title="No Cycle Selected",
                content="Please select a skill cycle to save.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
            return
        
        # Update cycle with form data
        self.current_cycle.name = self.view.cycle_name_edit.text()
        self.current_cycle.description = self.view.cycle_description_edit.toPlainText()
        self.current_cycle.trigger_key = self.view.cycle_trigger_edit.text()
        self.current_cycle.activation_condition = self.view.cycle_condition_edit.text()
        self.current_cycle.enabled = self.view.cycle_enabled_checkbox.isChecked()
        
        # Save cycle
        self.current_cycle.save()
        
        # Refresh cycles list to update the display
        self._load_cycles()
        
        # Show success message
        InfoBar.success(
            title="Cycle Saved",
            content=f"Skill cycle '{self.current_cycle.name}' has been saved.",
            parent=self.view,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_delete_cycle(self):
        """Handle delete cycle button click"""
        if not self.current_cycle:
            InfoBar.warning(
                title="No Cycle Selected",
                content="Please select a skill cycle to delete.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
            return
        
        # Delete cycle
        success = SkillCycle.delete(self.current_cycle.id)
        
        if success:
            # Refresh cycles list
            self._load_cycles()
            
            # Clear cycle form
            self._clear_cycle_form()
            
            # Reset current cycle
            self.current_cycle = None
            
            # Show success message
            InfoBar.success(
                title="Cycle Deleted",
                content="Skill cycle has been deleted.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
        else:
            # Show error message
            InfoBar.error(
                title="Delete Failed",
                content=f"Failed to delete skill cycle with ID {self.current_cycle.id}.",
                parent=self.view,
                position=InfoBarPosition.TOP,
                duration=3000
            )
    
    def _clear_cycle_form(self):
        """Clear cycle form fields"""
        self.view.cycle_name_edit.setText("")
        self.view.cycle_description_edit.setPlainText("")
        self.view.cycle_trigger_edit.setText("")
        self.view.cycle_condition_edit.setText("")
        self.view.cycle_enabled_checkbox.setChecked(False)
        
        # Clear the cycle steps list
        self.view.cycle_steps_list.clear()
    
    def _populate_cycle_form(self, cycle):
        """Populate cycle form with data
        
        Args:
            cycle: Skill cycle to display in the form
        """
        self.view.cycle_name_edit.setText(cycle.name)
        self.view.cycle_description_edit.setPlainText(cycle.description)
        self.view.cycle_trigger_edit.setText(cycle.trigger_key)
        self.view.cycle_condition_edit.setText(cycle.activation_condition)
        self.view.cycle_enabled_checkbox.setChecked(cycle.enabled)
        
        # Clear and populate the cycle steps list
        self.view.cycle_steps_list.clear()
        
        # Load all skills for reference
        skills = Skill.load_all()
        
        # Add each step to the list
        for i, step in enumerate(cycle.steps):
            if step.skill_id in skills:
                skill = skills[step.skill_id]
                item = QListWidgetItem(f"{i+1}. {skill.name} (Delay: {step.delay}s)")
                item.setData(Qt.UserRole, step)
                self.view.cycle_steps_list.addItem(item) 