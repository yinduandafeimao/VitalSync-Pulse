#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Application Controller

This module defines the main application controller that coordinates all sub-controllers.
"""

from PyQt5.QtCore import QObject

from vitalsync_pulse.modules.health_monitoring.health_monitor import HealthMonitor
from vitalsync_pulse.modules.skill_system.skill_models import SkillSystem
from vitalsync_pulse.modules.condition_system.condition_models import ConditionSystem

from .health_monitor_controller import HealthMonitorController
from .skill_cycle_controller import SkillCycleController
from .condition_trigger_controller import ConditionTriggerController


class AppController(QObject):
    """Application Controller class
    
    Responsible for coordinating all sub-controllers and managing application state.
    
    Attributes:
        main_window: Main application window
        health_monitor_controller: Controller for health monitoring
        skill_cycle_controller: Controller for skill cycles
        condition_trigger_controller: Controller for condition triggers
    """
    
    def __init__(self, main_window=None):
        """Initialize application controller
        
        Args:
            main_window: Main application window
        """
        super().__init__()
        
        self.main_window = main_window
        
        # Initialize models
        self.health_monitor = HealthMonitor()
        self.skill_system = SkillSystem() if hasattr(SkillSystem, '__call__') else None
        self.condition_system = ConditionSystem() if hasattr(ConditionSystem, '__call__') else None
        
        # Initialize controllers
        self.health_monitor_controller = None
        self.skill_cycle_controller = None
        self.condition_trigger_controller = None
        
        # Setup controllers when main window is available
        if main_window:
            self.setup_controllers()
    
    def setup_controllers(self):
        """Setup all controllers
        
        Connect controllers to their respective views and models.
        """
        if not self.main_window:
            return
        
        # Get views from main window
        health_monitor_view = self.main_window.health_monitor_interface.widget() if hasattr(self.main_window, 'health_monitor_interface') else None
        skill_cycle_view = self.main_window.skill_cycle_interface.widget() if hasattr(self.main_window, 'skill_cycle_interface') else None
        condition_trigger_view = self.main_window.condition_trigger_interface.widget() if hasattr(self.main_window, 'condition_trigger_interface') else None
        settings_view = self.main_window.settings_interface.widget() if hasattr(self.main_window, 'settings_interface') else None
        
        # Create controllers and connect views/models
        if health_monitor_view:
            self.health_monitor_controller = HealthMonitorController(health_monitor_view, self.health_monitor)
            self.health_monitor_controller.connect_view_model()
        
        if skill_cycle_view and self.skill_system:
            self.skill_cycle_controller = SkillCycleController(skill_cycle_view, self.skill_system)
            self.skill_cycle_controller.connect_view_model()
        
        if condition_trigger_view and self.condition_system:
            self.condition_trigger_controller = ConditionTriggerController(condition_trigger_view, self.condition_system)
            self.condition_trigger_controller.connect_view_model()
    
    def disconnect_controllers(self):
        """Disconnect all controllers
        
        Disconnect controllers from their views and models.
        """
        if self.health_monitor_controller:
            self.health_monitor_controller.disconnect_view_model()
        
        if self.skill_cycle_controller:
            self.skill_cycle_controller.disconnect_view_model()
        
        if self.condition_trigger_controller:
            self.condition_trigger_controller.disconnect_view_model()
    
    def save_all_data(self):
        """Save all application data
        
        Signal all controllers to save their data.
        """
        # Each controller should have implemented its own save methods
        # This method provides a central point to save all data
        pass
    
    def load_all_data(self):
        """Load all application data
        
        Signal all controllers to load their data.
        """
        # Each controller should have implemented its own load methods
        # This method provides a central point to load all data
        pass
    
    def on_navigation_switched(self, index):
        """Handle navigation interface switch
        
        Args:
            index: Index of the selected navigation item
        """
        # This method can be used to trigger actions when the user
        # switches between different views in the main window
        pass
    
    def shutdown(self):
        """Perform shutdown operations
        
        Save data and disconnect controllers before application exit.
        """
        # Save all data
        self.save_all_data()
        
        # Disconnect controllers
        self.disconnect_controllers() 