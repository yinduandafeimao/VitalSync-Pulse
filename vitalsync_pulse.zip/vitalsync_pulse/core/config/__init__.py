"""
配置管理模块

这个模块负责管理应用程序的配置，包括读取、保存和提供默认配置。
"""

from vitalsync_pulse.core.config.config_manager import ConfigManager, get_config
from vitalsync_pulse.core.config.defaults import DEFAULT_CONFIG

__all__ = ['ConfigManager', 'get_config', 'DEFAULT_CONFIG'] 