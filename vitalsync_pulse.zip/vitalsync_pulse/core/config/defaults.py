#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
默认配置模块

这个模块定义了应用程序的默认配置值。
"""

# 默认配置
DEFAULT_CONFIG = {
    # 应用程序基本配置
    'app': {
        'version': '1.0.0',
        'theme': 'light',
        'language': 'zh_CN',
        'first_run': True
    },
    
    # 血条监控配置
    'health_monitor': {
        'update_interval': 0.5,  # 更新间隔（秒）
        'auto_select_enabled': False,  # 是否启用自动选择低血量队友
        'health_threshold': 50.0,  # 血量阈值（百分比）
        'cooldown_time': 2.0,  # 冷却时间（秒）
        'hotkeys': {
            'start_monitoring': 'f9',
            'stop_monitoring': 'f10'
        }
    },
    
    # 技能系统配置
    'skill_system': {
        'enabled': True,
        'hotkeys': {
            'start_cycle': 'f11',
            'stop_cycle': 'f12'
        },
        'default_press_delay': 0.0,
        'default_release_delay': 0.05
    },
    
    # 队友识别配置
    'team_recognition': {
        'contrast': 1.0,
        'brightness': 1.0,
        'sample_count': 3,
        'confidence_threshold': 0.7
    },
    
    # UI配置
    'ui': {
        'window_width': 1280,
        'window_height': 720,
        'opacity': 1.0,
        'show_tooltips': True
    },
    
    # 日志配置
    'logging': {
        'level': 'INFO',
        'file_enabled': True,
        'console_enabled': True,
        'max_file_size': 10485760,  # 10MB
        'backup_count': 5
    }
}

# 获取默认配置的副本
def get_default_config():
    """
    获取默认配置的副本
    
    返回:
        dict: 默认配置的副本
    """
    import copy
    return copy.deepcopy(DEFAULT_CONFIG)

# 获取特定部分的默认配置
def get_default_section(section):
    """
    获取特定部分的默认配置
    
    参数:
        section (str): 配置部分名称
        
    返回:
        dict: 指定部分的默认配置，如果不存在则返回空字典
    """
    import copy
    return copy.deepcopy(DEFAULT_CONFIG.get(section, {})) 