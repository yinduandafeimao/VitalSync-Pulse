#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
VitalSync Pulse - Main Entry Point

This module serves as the entry point for the VitalSync Pulse application.
"""

import sys
import os
import logging

# 添加项目根目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt

from vitalsync_pulse.ui.views.main_window import MainWindow
from vitalsync_pulse.core.controllers.app_controller import AppController

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("vitalsync_pulse.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# Application information
APP_NAME = "VitalSync Pulse"
APP_VERSION = "1.0.0"


def main():
    """Main function to start the application"""
    # Create Qt application
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    
    # Set application style
    app.setStyle('Fusion')
    
    # Enable high DPI scaling
    app.setAttribute(Qt.AA_EnableHighDpiScaling)
    app.setAttribute(Qt.AA_UseHighDpiPixmaps)
    
    # Create main window
    window = MainWindow()
    
    # Create application controller
    app_controller = AppController(window)
    
    # Connect window signals to controller
    window.navigationInterface.currentIndexChanged.connect(app_controller.on_navigation_switched)
    
    # Connect application exit signals
    app.aboutToQuit.connect(app_controller.shutdown)
    
    # Show main window
    window.show()
    
    logger.info(f"{APP_NAME} v{APP_VERSION} started successfully.")
    
    # Start application event loop
    sys.exit(app.exec_())


if __name__ == "__main__":
    main() 