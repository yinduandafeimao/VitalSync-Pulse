#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
运行单元测试

这个脚本用于运行项目的所有单元测试。
"""

import unittest
import sys
import os

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

# 导入测试套件
from tests.test_suite import create_test_suite


def run_tests():
    """运行所有单元测试"""
    print("=" * 80)
    print("运行 VitalSync Pulse 单元测试")
    print("=" * 80)
    
    # 创建测试套件
    suite = create_test_suite()
    
    # 创建测试运行器
    runner = unittest.TextTestRunner(verbosity=2)
    
    # 运行测试
    result = runner.run(suite)
    
    print("\n" + "=" * 80)
    print(f"测试完成: 运行 {result.testsRun} 个测试")
    print(f"成功: {result.testsRun - len(result.errors) - len(result.failures)}")
    print(f"失败: {len(result.failures)}")
    print(f"错误: {len(result.errors)}")
    print("=" * 80)
    
    # 返回是否所有测试都通过
    return len(result.failures) == 0 and len(result.errors) == 0


if __name__ == "__main__":
    # 运行测试并设置退出代码
    success = run_tests()
    sys.exit(0 if success else 1) 