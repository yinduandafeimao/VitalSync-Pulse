"""
UI对话框模块

这个模块包含了应用程序使用的对话框，如血条相关对话框、条件相关对话框等。
"""

# 将来会从子模块导入
# from vitalsync_pulse.ui.dialogs.health_dialogs import HealthBarPositionDialog, HealthBarColorDialog
# from vitalsync_pulse.ui.dialogs.condition_dialogs import ConditionEditDialog 