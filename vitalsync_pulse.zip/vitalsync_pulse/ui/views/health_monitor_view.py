#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
健康监控页面视图

这个模块定义了健康监控功能的用户界面。
"""

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout, 
    QGroupBox, QSplitter, QFrame
)

from qfluentwidgets import (
    PushButton, SwitchButton, SubtitleLabel, BodyLabel, 
    CardWidget, PrimaryPushButton, TransparentPushButton,
    InfoBar, InfoBarPosition, FluentIcon as FIF
)

class HealthMonitorView(QWidget):
    """健康监控页面视图"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        """设置用户界面"""
        # 主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(10)
        
        # 标题
        title_label = SubtitleLabel("健康监控")
        main_layout.addWidget(title_label)
        
        # 控制面板卡片
        control_card = CardWidget()
        control_layout = QVBoxLayout(control_card)
        
        # 监控控制
        monitor_group = QGroupBox("监控控制")
        monitor_layout = QHBoxLayout(monitor_group)
        
        self.start_button = PrimaryPushButton("开始监控")
        self.stop_button = PushButton("停止监控")
        self.stop_button.setEnabled(False)
        
        monitor_layout.addWidget(self.start_button)
        monitor_layout.addWidget(self.stop_button)
        monitor_layout.addStretch()
        
        # 状态指示
        status_layout = QHBoxLayout()
        status_layout.addWidget(QLabel("监控状态:"))
        self.status_label = BodyLabel("未运行")
        self.status_label.setStyleSheet("color: gray;")
        status_layout.addWidget(self.status_label)
        status_layout.addStretch()
        
        # 添加到控制布局
        control_layout.addWidget(monitor_group)
        control_layout.addLayout(status_layout)
        
        # 团队成员卡片
        team_card = CardWidget()
        team_layout = QVBoxLayout(team_card)
        
        # 团队成员标题
        team_header = QHBoxLayout()
        team_header.addWidget(SubtitleLabel("团队成员"))
        
        self.add_member_button = TransparentPushButton("添加成员")
        self.add_member_button.setIcon(FIF.ADD)
        team_header.addWidget(self.add_member_button)
        team_header.addStretch()
        
        # 团队成员网格（占位）
        self.team_grid = QGridLayout()
        self.team_grid.setSpacing(10)
        
        # 添加占位文本
        placeholder = BodyLabel('暂无团队成员，请点击"添加成员"按钮添加')
        placeholder.setAlignment(Qt.AlignCenter)
        self.team_grid.addWidget(placeholder, 0, 0)
        
        # 添加到团队布局
        team_layout.addLayout(team_header)
        team_layout.addLayout(self.team_grid)
        
        # 添加卡片到主布局
        main_layout.addWidget(control_card)
        main_layout.addWidget(team_card, 1)  # 团队卡片可扩展
        
        # 连接信号槽
        self.start_button.clicked.connect(self._on_start_clicked)
        self.stop_button.clicked.connect(self._on_stop_clicked)
        self.add_member_button.clicked.connect(self._on_add_member_clicked)
    
    def _on_start_clicked(self):
        """开始监控按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.status_label.setText("正在运行")
        self.status_label.setStyleSheet("color: green;")
        
        # 显示信息条
        InfoBar.success(
            title="监控已启动",
            content="健康监控功能已成功启动",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_stop_clicked(self):
        """停止监控按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.status_label.setText("未运行")
        self.status_label.setStyleSheet("color: gray;")
        
        # 显示信息条
        InfoBar.information(
            title="监控已停止",
            content="健康监控功能已停止",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_add_member_clicked(self):
        """添加成员按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        InfoBar.success(
            title="功能开发中",
            content="添加成员功能正在开发中",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        ) 