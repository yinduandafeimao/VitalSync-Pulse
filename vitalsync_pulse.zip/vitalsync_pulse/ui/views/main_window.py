#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
VitalSync Pulse 主窗口

这个模块定义了应用程序的主窗口界面。
"""

import sys
import os
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout

# 导入QFluentWidgets组件
from qfluentwidgets import (
    FluentWindow, NavigationItemPosition, FluentIcon as FIF, 
    NavigationInterface, setTheme, Theme
)

# 导入视图
from vitalsync_pulse.ui.views.health_monitor_view import HealthMonitorView
from vitalsync_pulse.ui.views.skill_cycle_view import SkillCycleView
from vitalsync_pulse.ui.views.condition_trigger_view import ConditionTriggerView
from vitalsync_pulse.ui.views.settings_view import SettingsView

class MainWindow(FluentWindow):
    """VitalSync Pulse 主窗口"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VitalSync Pulse")
        self.resize(1200, 800)
        
        # 加载图标
        icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), 'app_icon.ico')
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        
        # 初始化界面
        self._init_navigation()
        self._init_window()
    
    def _init_navigation(self):
        """初始化导航栏"""
        # 创建导航项
        self.navigation_interface = NavigationInterface(
            self, showMenuButton=True, showReturnButton=False
        )
        
        # 创建页面
        self.health_monitor_view = HealthMonitorView()
        self.skill_cycle_view = SkillCycleView()
        self.condition_trigger_view = ConditionTriggerView()
        self.settings_view = SettingsView()
        
        # 添加导航项
        self.addSubInterface(
            self.health_monitor_view, 
            "健康监控", 
            FIF.HEART,
            position=NavigationItemPosition.TOP
        )
        
        self.addSubInterface(
            self.skill_cycle_view, 
            "技能循环", 
            FIF.GAME,
            position=NavigationItemPosition.TOP
        )
        
        self.addSubInterface(
            self.condition_trigger_view, 
            "条件触发", 
            FIF.FLAG,
            position=NavigationItemPosition.TOP
        )
        
        self.addSubInterface(
            self.settings_view, 
            "设置", 
            FIF.SETTING,
            position=NavigationItemPosition.BOTTOM
        )
        
        # 设置为初始页面
        self.navigation_interface.setCurrentItem("健康监控")
    
    def _init_window(self):
        """初始化窗口设置"""
        # 设置主题
        setTheme(Theme.AUTO)
        
        # 应用样式
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
        """)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_()) 