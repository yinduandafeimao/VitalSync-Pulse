#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
技能循环页面视图

这个模块定义了技能循环功能的用户界面。
"""

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout, 
    QGroupBox, QSplitter, QFrame, QListWidget, QListWidgetItem,
    QScrollArea
)

from qfluentwidgets import (
    PushButton, SwitchButton, SubtitleLabel, BodyLabel, 
    CardWidget, PrimaryPushButton, TransparentPushButton,
    InfoBar, InfoBarPosition, FluentIcon as FIF,
    ComboBox, LineEdit, SpinBox
)

class SkillCycleView(QWidget):
    """技能循环页面视图"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        """设置用户界面"""
        # 主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(10)
        
        # 标题
        title_label = SubtitleLabel("技能循环")
        main_layout.addWidget(title_label)
        
        # 创建水平分割器
        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        
        # 左侧技能列表卡片
        skill_list_card = CardWidget()
        skill_list_layout = QVBoxLayout(skill_list_card)
        
        # 技能列表标题
        skill_list_header = QHBoxLayout()
        skill_list_header.addWidget(SubtitleLabel("技能列表"))
        
        self.add_skill_button = TransparentPushButton("添加技能")
        self.add_skill_button.setIcon(FIF.ADD.icon())
        skill_list_header.addWidget(self.add_skill_button)
        skill_list_header.addStretch()
        
        # 技能列表
        self.skill_list = QListWidget()
        self.skill_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #e0e0e0;
                border-radius: 5px;
                background-color: white;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #f0f0f0;
            }
            QListWidget::item:selected {
                background-color: #e6f2ff;
                color: #0078d4;
            }
        """)
        
        # 添加示例项目
        for i in range(1, 6):
            item = QListWidgetItem(f"技能 {i}")
            item.setIcon(FIF.GAME.icon())
            self.skill_list.addItem(item)
        
        # 添加到技能列表布局
        skill_list_layout.addLayout(skill_list_header)
        skill_list_layout.addWidget(self.skill_list)
        
        # 右侧技能详情卡片
        skill_detail_card = CardWidget()
        skill_detail_layout = QVBoxLayout(skill_detail_card)
        
        # 技能详情标题
        skill_detail_layout.addWidget(SubtitleLabel("技能详情"))
        
        # 技能详情表单
        form_layout = QGridLayout()
        form_layout.setColumnStretch(1, 1)
        form_layout.setVerticalSpacing(10)
        form_layout.setHorizontalSpacing(15)
        
        # 技能名称
        form_layout.addWidget(QLabel("技能名称:"), 0, 0)
        self.name_edit = LineEdit()
        self.name_edit.setPlaceholderText("输入技能名称")
        form_layout.addWidget(self.name_edit, 0, 1)
        
        # 技能类型
        form_layout.addWidget(QLabel("技能类型:"), 1, 0)
        self.type_combo = ComboBox()
        self.type_combo.addItems(["主动技能", "被动技能", "增益技能", "减益技能"])
        form_layout.addWidget(self.type_combo, 1, 1)
        
        # 冷却时间
        form_layout.addWidget(QLabel("冷却时间(秒):"), 2, 0)
        self.cooldown_spin = SpinBox()
        self.cooldown_spin.setRange(0, 300)
        self.cooldown_spin.setValue(30)
        form_layout.addWidget(self.cooldown_spin, 2, 1)
        
        # 优先级
        form_layout.addWidget(QLabel("优先级:"), 3, 0)
        self.priority_spin = SpinBox()
        self.priority_spin.setRange(1, 10)
        self.priority_spin.setValue(5)
        form_layout.addWidget(self.priority_spin, 3, 1)
        
        # 技能描述
        form_layout.addWidget(QLabel("技能描述:"), 4, 0, Qt.AlignTop)
        self.desc_edit = LineEdit()
        self.desc_edit.setPlaceholderText("输入技能描述")
        form_layout.addWidget(self.desc_edit, 4, 1)
        
        # 操作按钮
        button_layout = QHBoxLayout()
        self.save_button = PrimaryPushButton("保存")
        self.delete_button = PushButton("删除")
        self.delete_button.setIcon(FIF.DELETE.icon())
        
        button_layout.addWidget(self.save_button)
        button_layout.addWidget(self.delete_button)
        button_layout.addStretch()
        
        # 添加到技能详情布局
        skill_detail_layout.addLayout(form_layout)
        skill_detail_layout.addStretch()
        skill_detail_layout.addLayout(button_layout)
        
        # 设置左右两侧宽度比例
        splitter.addWidget(skill_list_card)
        splitter.addWidget(skill_detail_card)
        splitter.setSizes([300, 500])  # 设置初始宽度比例
        
        # 添加分割器到主布局
        main_layout.addWidget(splitter)
        
        # 连接信号槽
        self.add_skill_button.clicked.connect(self._on_add_skill_clicked)
        self.save_button.clicked.connect(self._on_save_clicked)
        self.delete_button.clicked.connect(self._on_delete_clicked)
        self.skill_list.currentItemChanged.connect(self._on_skill_selected)
    
    def _on_add_skill_clicked(self):
        """添加技能按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        item = QListWidgetItem(f"新技能 {self.skill_list.count() + 1}")
        item.setIcon(FIF.GAME.icon())
        self.skill_list.addItem(item)
        self.skill_list.setCurrentItem(item)
        
        # 清空表单
        self.name_edit.setText(item.text())
        self.type_combo.setCurrentIndex(0)
        self.cooldown_spin.setValue(30)
        self.priority_spin.setValue(5)
        self.desc_edit.setText("")
        
        # 显示信息条
        InfoBar.success(
            title="已添加新技能",
            content="请编辑技能详情并保存",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_save_clicked(self):
        """保存按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        current_item = self.skill_list.currentItem()
        if current_item:
            current_item.setText(self.name_edit.text())
            
            # 显示信息条
            InfoBar.success(
                title="保存成功",
                content="技能信息已更新",
                parent=self,
                position=InfoBarPosition.TOP,
                duration=3000
            )
        else:
            InfoBar.warning(
                title="保存失败",
                content="请先选择一个技能",
                parent=self,
                position=InfoBarPosition.TOP,
                duration=3000
            )
    
    def _on_delete_clicked(self):
        """删除按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        current_row = self.skill_list.currentRow()
        if current_row >= 0:
            self.skill_list.takeItem(current_row)
            
            # 显示信息条
            InfoBar.information(
                title="删除成功",
                content="技能已被删除",
                parent=self,
                position=InfoBarPosition.TOP,
                duration=3000
            )
        else:
            InfoBar.warning(
                title="删除失败",
                content="请先选择一个技能",
                parent=self,
                position=InfoBarPosition.TOP,
                duration=3000
            )
    
    def _on_skill_selected(self, current, previous):
        """技能选择事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        if current:
            # 模拟加载选中技能的数据
            self.name_edit.setText(current.text())
            self.type_combo.setCurrentIndex(self.skill_list.row(current) % 4)  # 模拟不同类型
            self.cooldown_spin.setValue(30 + self.skill_list.row(current) * 5)  # 模拟不同冷却时间
            self.priority_spin.setValue(5)
            self.desc_edit.setText(f"{current.text()}的详细描述...") 