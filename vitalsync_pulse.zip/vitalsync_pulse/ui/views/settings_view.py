#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
设置页面视图

这个模块定义了应用程序的设置界面。
"""

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout, 
    QGroupBox, QSplitter, QFrame, QFileDialog
)

from qfluentwidgets import (
    PushButton, SwitchButton, SubtitleLabel, BodyLabel, 
    CardWidget, PrimaryPushButton, TransparentPushButton,
    InfoBar, InfoBarPosition, FluentIcon as FIF,
    ComboBox, LineEdit, SpinBox, RangeSettingCard,
    SettingCardGroup, SwitchSettingCard, ComboBoxSettingCard,
    PushSettingCard, ScrollArea, ExpandLayout, Theme, setTheme
)

class SettingsView(ScrollArea):
    """设置页面视图"""
    
    themeChanged = pyqtSignal(Theme)
    voiceVolumeChanged = pyqtSignal(int)
    voiceRateChanged = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        """设置用户界面"""
        self.setObjectName("settingsView")
        
        # 创建滚动区域内容部件
        self.scroll_widget = QWidget()
        self.setWidget(self.scroll_widget)
        self.setWidgetResizable(True)
        
        # 设置滚动区域样式
        self.setStyleSheet("""
            SettingsView {
                background-color: transparent;
                border: none;
            }
        """)
        
        # 主布局 - 使用 ExpandLayout 自动调整内容
        self.expand_layout = ExpandLayout(self.scroll_widget)
        self.expand_layout.setContentsMargins(20, 20, 20, 20)
        self.expand_layout.setSpacing(20)
        
        # 标题
        self.title_label = SubtitleLabel("设置")
        self.expand_layout.addWidget(self.title_label)
        
        # === 常规设置 ===
        self.general_group = SettingCardGroup("常规设置", self.scroll_widget)
        
        # 主题设置
        self.theme_card = ComboBoxSettingCard(
            icon=FIF.BRUSH,
            title="应用主题",
            content="设置应用的主题样式",
            texts=["自动", "亮色", "暗色"],
            parent=self.general_group
        )
        self.general_group.addSettingCard(self.theme_card)
        
        # 自动启动设置
        self.auto_start_card = SwitchSettingCard(
            icon=FIF.POWER_BUTTON,
            title="开机自启",
            content="设置应用程序是否在系统启动时自动运行",
            parent=self.general_group
        )
        self.general_group.addSettingCard(self.auto_start_card)
        
        # === 语音设置 ===
        self.voice_group = SettingCardGroup("语音设置", self.scroll_widget)
        
        # 语音引擎设置
        self.voice_engine_card = ComboBoxSettingCard(
            icon=FIF.MICROPHONE,
            title="语音引擎",
            content="选择语音提示使用的引擎",
            texts=["中文女声 (普通话)", "中文男声 (普通话)", "英文女声", "英文男声"],
            parent=self.voice_group
        )
        self.voice_group.addSettingCard(self.voice_engine_card)
        
        # 语音音量设置
        self.voice_volume_card = RangeSettingCard(
            configItem=None,  # 需要传入一个configItem参数
            icon=FIF.SPEAKER,
            title="语音音量",
            content="调整语音提示的音量",
            parent=self.voice_group
        )
        self.voice_volume_card.slider.setRange(0, 100)
        self.voice_volume_card.slider.setValue(80)
        self.voice_group.addSettingCard(self.voice_volume_card)
        
        # 语音速率设置
        self.voice_rate_card = RangeSettingCard(
            configItem=None,  # 需要传入一个configItem参数
            icon=FIF.SPEED_HIGH,
            title="语音速率",
            content="调整语音提示的速度",
            parent=self.voice_group
        )
        self.voice_rate_card.slider.setRange(1, 10)
        self.voice_rate_card.slider.setValue(5)
        self.voice_group.addSettingCard(self.voice_rate_card)
        
        # === 热键设置 ===
        self.hotkey_group = SettingCardGroup("热键设置", self.scroll_widget)
        
        # 开始监控热键设置
        self.start_hotkey_card = PushSettingCard(
            icon=FIF.KEYBOARD,
            title="开始监控热键",
            content="按下按钮，然后按下您想使用的热键组合",
            texts=["设置热键"],
            parent=self.hotkey_group
        )
        self.hotkey_group.addSettingCard(self.start_hotkey_card)
        
        # 停止监控热键设置
        self.stop_hotkey_card = PushSettingCard(
            icon=FIF.KEYBOARD,
            title="停止监控热键",
            content="按下按钮，然后按下您想使用的热键组合",
            texts=["设置热键"],
            parent=self.hotkey_group
        )
        self.hotkey_group.addSettingCard(self.stop_hotkey_card)
        
        # === 关于信息 ===
        self.about_group = SettingCardGroup("关于", self.scroll_widget)
        
        # 版本信息
        self.version_card = PushSettingCard(
            icon=FIF.INFO,
            title="版本信息",
            content="VitalSync Pulse v1.0.0",
            texts=[],
            parent=self.about_group
        )
        self.about_group.addSettingCard(self.version_card)
        
        # 检查更新
        self.update_card = PushSettingCard(
            icon=FIF.UPDATE,
            title="检查更新",
            content="检查是否有新版本可用",
            texts=["检查更新"],
            parent=self.about_group
        )
        self.about_group.addSettingCard(self.update_card)
        
        # 导出设置
        self.export_card = PushSettingCard(
            icon=FIF.SAVE,
            title="导出设置",
            content="将当前设置导出到文件",
            texts=["导出"],
            parent=self.about_group
        )
        self.about_group.addSettingCard(self.export_card)
        
        # 导入设置
        self.import_card = PushSettingCard(
            icon=FIF.FOLDER,
            title="导入设置",
            content="从文件导入设置",
            texts=["导入"],
            parent=self.about_group
        )
        self.about_group.addSettingCard(self.import_card)
        
        # 添加所有分组到布局
        self.expand_layout.addWidget(self.general_group)
        self.expand_layout.addWidget(self.voice_group)
        self.expand_layout.addWidget(self.hotkey_group)
        self.expand_layout.addWidget(self.about_group)
        
        # 连接信号槽
        self.theme_card.comboBox.currentIndexChanged.connect(self._on_theme_changed)
        self.voice_volume_card.slider.valueChanged.connect(self._on_volume_changed)
        self.voice_rate_card.slider.valueChanged.connect(self._on_rate_changed)
        self.start_hotkey_card.pushButton.clicked.connect(self._on_start_hotkey_clicked)
        self.stop_hotkey_card.pushButton.clicked.connect(self._on_stop_hotkey_clicked)
        self.update_card.pushButton.clicked.connect(self._on_update_clicked)
        self.export_card.pushButton.clicked.connect(self._on_export_clicked)
        self.import_card.pushButton.clicked.connect(self._on_import_clicked)
    
    def _on_theme_changed(self, index):
        """主题设置改变事件"""
        theme_map = {
            0: Theme.AUTO,
            1: Theme.LIGHT,
            2: Theme.DARK
        }
        theme = theme_map.get(index, Theme.AUTO)
        self.themeChanged.emit(theme)
    
    def _on_volume_changed(self, value):
        """音量设置改变事件"""
        self.voice_volume_card.valueLabel.setText(str(value))
        self.voiceVolumeChanged.emit(value)
    
    def _on_rate_changed(self, value):
        """语速设置改变事件"""
        self.voice_rate_card.valueLabel.setText(str(value))
        self.voiceRateChanged.emit(value)
    
    def _on_start_hotkey_clicked(self):
        """开始监控热键设置事件"""
        # 实现热键设置逻辑
        InfoBar.success(
            title="热键设置",
            content="请按下您想设置的热键组合",
            orient=Qt.Horizontal,
            isClosable=True,
            position=InfoBarPosition.TOP,
            duration=3000,
            parent=self
        )
    
    def _on_stop_hotkey_clicked(self):
        """停止监控热键设置事件"""
        # 实现热键设置逻辑
        InfoBar.success(
            title="热键设置",
            content="请按下您想设置的热键组合",
            orient=Qt.Horizontal,
            isClosable=True,
            position=InfoBarPosition.TOP,
            duration=3000,
            parent=self
        )
    
    def _on_update_clicked(self):
        """检查更新事件"""
        InfoBar.info(
            title="检查更新",
            content="正在检查新版本...",
            orient=Qt.Horizontal,
            isClosable=True,
            position=InfoBarPosition.TOP,
            duration=3000,
            parent=self
        )
    
    def _on_export_clicked(self):
        """导出设置事件"""
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "导出设置",
            "vitalsync_settings.json",
            "JSON Files (*.json)"
        )
        
        if file_path:
            InfoBar.success(
                title="导出设置",
                content=f"设置已导出到 {file_path}",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=3000,
                parent=self
            )
    
    def _on_import_clicked(self):
        """导入设置事件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "导入设置",
            "",
            "JSON Files (*.json)"
        )
        
        if file_path:
            InfoBar.success(
                title="导入设置",
                content=f"已从 {file_path} 导入设置",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=3000,
                parent=self
            ) 