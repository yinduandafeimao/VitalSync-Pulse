#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
条件触发页面视图

这个模块定义了条件触发功能的用户界面。
"""

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QIcon, QColor
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout, 
    QGroupBox, QSplitter, QFrame, QListWidget, QListWidgetItem,
    QScrollArea, QTableWidget, QTableWidgetItem, QHeaderView,
    QTabWidget, QMenu, QAction
)

from qfluentwidgets import (
    PushButton, SwitchButton, SubtitleLabel, BodyLabel, 
    CardWidget, PrimaryPushButton, TransparentPushButton,
    InfoBar, InfoBarPosition, FluentIcon as FIF,
    ComboBox, LineEdit, SpinBox, ToolButton, FlowLayout,
    StrongBodyLabel, ToggleButton, ColorDialog
)

class ConditionTriggerView(QWidget):
    """条件触发页面视图"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        """设置用户界面"""
        # 主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(10)
        
        # 标题
        title_label = SubtitleLabel("条件触发")
        main_layout.addWidget(title_label)
        
        # 创建标签页
        self.tab_widget = QTabWidget()
        self.tab_widget.setObjectName("conditionTabs")
        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #e0e0e0;
                border-radius: 5px;
                background-color: white;
            }
            QTabBar::tab {
                padding: 8px 16px;
                margin: 2px 4px 0px 0px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                background-color: white;
                border: 1px solid #e0e0e0;
                border-bottom: none;
            }
            QTabBar::tab:!selected {
                background-color: #f5f5f5;
                border: 1px solid #e0e0e0;
            }
        """)
        
        # 添加条件列表页
        self.conditions_tab = QWidget()
        self.setup_conditions_tab()
        self.tab_widget.addTab(self.conditions_tab, "条件列表")
        
        # 添加条件组合页
        self.composite_tab = QWidget()
        self.setup_composite_tab()
        self.tab_widget.addTab(self.composite_tab, "条件组合")
        
        # 添加条件监控页
        self.monitor_tab = QWidget()
        self.setup_monitor_tab()
        self.tab_widget.addTab(self.monitor_tab, "条件监控")
        
        # 添加标签页到主布局
        main_layout.addWidget(self.tab_widget)
    
    def setup_conditions_tab(self):
        """设置条件列表标签页"""
        layout = QVBoxLayout(self.conditions_tab)
        
        # 控制面板卡片
        control_card = CardWidget()
        control_layout = QHBoxLayout(control_card)
        
        # 添加条件按钮
        self.add_color_condition_btn = PushButton("添加颜色条件")
        self.add_color_condition_btn.setIcon(FIF.PALETTE.icon())
        
        self.add_text_condition_btn = PushButton("添加文本条件")
        self.add_text_condition_btn.setIcon(FIF.DOCUMENT.icon())
        
        self.add_time_condition_btn = PushButton("添加时间条件")
        self.add_time_condition_btn.setIcon(FIF.STOP_WATCH.icon())
        
        control_layout.addWidget(self.add_color_condition_btn)
        control_layout.addWidget(self.add_text_condition_btn)
        control_layout.addWidget(self.add_time_condition_btn)
        control_layout.addStretch()
        
        # 条件表格卡片
        table_card = CardWidget()
        table_layout = QVBoxLayout(table_card)
        
        # 条件表格
        self.condition_table = QTableWidget()
        self.condition_table.setColumnCount(5)
        self.condition_table.setHorizontalHeaderLabels(["名称", "类型", "状态", "上次触发", "操作"])
        self.condition_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.condition_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.condition_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.condition_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.condition_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        
        # 添加示例数据
        self.condition_table.setRowCount(5)
        for i in range(5):
            # 名称
            name_item = QTableWidgetItem(f"条件 {i+1}")
            self.condition_table.setItem(i, 0, name_item)
            
            # 类型
            types = ["颜色条件", "文本条件", "时间条件"]
            type_item = QTableWidgetItem(types[i % 3])
            self.condition_table.setItem(i, 1, type_item)
            
            # 状态
            status_item = QTableWidgetItem()
            status_item.setCheckState(Qt.Checked if i % 2 == 0 else Qt.Unchecked)
            self.condition_table.setItem(i, 2, status_item)
            
            # 上次触发
            last_trigger_item = QTableWidgetItem("2023-05-24 12:34:56" if i % 2 == 0 else "未触发")
            self.condition_table.setItem(i, 3, last_trigger_item)
            
            # 操作按钮单元格
            operation_layout = QHBoxLayout()
            operation_layout.setContentsMargins(4, 4, 4, 4)
            operation_layout.setSpacing(4)
            
            edit_btn = ToolButton()
            edit_btn.setIcon(FIF.EDIT.icon())
            edit_btn.setToolTip("编辑")
            
            delete_btn = ToolButton()
            delete_btn.setIcon(FIF.DELETE.icon())
            delete_btn.setToolTip("删除")
            
            operation_layout.addWidget(edit_btn)
            operation_layout.addWidget(delete_btn)
            operation_layout.addStretch()
            
            operation_widget = QWidget()
            operation_widget.setLayout(operation_layout)
            self.condition_table.setCellWidget(i, 4, operation_widget)
        
        table_layout.addWidget(self.condition_table)
        
        # 添加卡片到标签页布局
        layout.addWidget(control_card)
        layout.addWidget(table_card)
        
        # 连接信号槽
        self.add_color_condition_btn.clicked.connect(self._on_add_color_condition)
        self.add_text_condition_btn.clicked.connect(self._on_add_text_condition)
        self.add_time_condition_btn.clicked.connect(self._on_add_time_condition)
    
    def setup_composite_tab(self):
        """设置条件组合标签页"""
        layout = QVBoxLayout(self.composite_tab)
        
        # 创建水平分割器
        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        
        # 左侧组合列表卡片
        composite_list_card = CardWidget()
        composite_list_layout = QVBoxLayout(composite_list_card)
        
        # 组合列表标题
        composite_list_header = QHBoxLayout()
        composite_list_header.addWidget(SubtitleLabel("组合列表"))
        
        self.add_composite_button = TransparentPushButton("添加组合")
        self.add_composite_button.setIcon(FIF.ADD.icon())
        composite_list_header.addWidget(self.add_composite_button)
        composite_list_header.addStretch()
        
        # 组合列表
        self.composite_list = QListWidget()
        
        # 添加示例项目
        for i in range(1, 4):
            item = QListWidgetItem(f"条件组合 {i}")
            item.setIcon(FIF.FLAG.icon())
            self.composite_list.addItem(item)
        
        # 添加到组合列表布局
        composite_list_layout.addLayout(composite_list_header)
        composite_list_layout.addWidget(self.composite_list)
        
        # 右侧组合详情卡片
        composite_detail_card = CardWidget()
        composite_detail_layout = QVBoxLayout(composite_detail_card)
        
        # 组合详情标题
        composite_detail_layout.addWidget(SubtitleLabel("组合详情"))
        
        # 组合详情表单
        form_layout = QGridLayout()
        form_layout.setColumnStretch(1, 1)
        form_layout.setVerticalSpacing(10)
        form_layout.setHorizontalSpacing(15)
        
        # 组合名称
        form_layout.addWidget(QLabel("组合名称:"), 0, 0)
        self.composite_name_edit = LineEdit()
        self.composite_name_edit.setPlaceholderText("输入组合名称")
        form_layout.addWidget(self.composite_name_edit, 0, 1)
        
        # 组合类型
        form_layout.addWidget(QLabel("组合类型:"), 1, 0)
        self.composite_type_combo = ComboBox()
        self.composite_type_combo.addItems(["AND (所有条件满足)", "OR (任一条件满足)"])
        form_layout.addWidget(self.composite_type_combo, 1, 1)
        
        # 包含的条件
        form_layout.addWidget(QLabel("包含的条件:"), 2, 0, Qt.AlignTop)
        
        # 条件流布局
        self.conditions_flow_widget = QWidget()
        self.conditions_flow_layout = FlowLayout(self.conditions_flow_widget)
        self.conditions_flow_layout.setContentsMargins(0, 0, 0, 0)
        self.conditions_flow_layout.setSpacing(8)
        
        # 添加示例条件标签
        for i in range(1, 4):
            condition_label = BodyLabel(f"条件 {i}")
            condition_label.setStyleSheet("""
                padding: 4px 8px;
                background-color: #f0f0f0;
                border-radius: 4px;
            """)
            self.conditions_flow_layout.addWidget(condition_label)
        
        # 添加条件按钮
        add_condition_btn = TransparentPushButton("添加条件")
        add_condition_btn.setIcon(FIF.ADD.icon())
        self.conditions_flow_layout.addWidget(add_condition_btn)
        
        form_layout.addWidget(self.conditions_flow_widget, 2, 1)
        
        # 操作按钮
        button_layout = QHBoxLayout()
        self.save_composite_button = PrimaryPushButton("保存")
        self.delete_composite_button = PushButton("删除")
        self.delete_composite_button.setIcon(FIF.DELETE.icon())
        
        button_layout.addWidget(self.save_composite_button)
        button_layout.addWidget(self.delete_composite_button)
        button_layout.addStretch()
        
        # 添加到组合详情布局
        composite_detail_layout.addLayout(form_layout)
        composite_detail_layout.addStretch()
        composite_detail_layout.addLayout(button_layout)
        
        # 设置左右两侧宽度比例
        splitter.addWidget(composite_list_card)
        splitter.addWidget(composite_detail_card)
        splitter.setSizes([300, 500])  # 设置初始宽度比例
        
        # 添加分割器到标签页布局
        layout.addWidget(splitter)
        
        # 连接信号槽
        self.add_composite_button.clicked.connect(self._on_add_composite_clicked)
        add_condition_btn.clicked.connect(self._on_add_condition_to_composite)
        self.save_composite_button.clicked.connect(self._on_save_composite_clicked)
        self.delete_composite_button.clicked.connect(self._on_delete_composite_clicked)
        self.composite_list.currentItemChanged.connect(self._on_composite_selected)
    
    def setup_monitor_tab(self):
        """设置条件监控标签页"""
        layout = QVBoxLayout(self.monitor_tab)
        
        # 控制面板卡片
        control_card = CardWidget()
        control_layout = QHBoxLayout(control_card)
        
        # 监控控制
        self.start_monitor_button = PrimaryPushButton("开始监控")
        self.stop_monitor_button = PushButton("停止监控")
        self.stop_monitor_button.setEnabled(False)
        
        # 添加到控制布局
        control_layout.addWidget(self.start_monitor_button)
        control_layout.addWidget(self.stop_monitor_button)
        
        # 状态指示
        control_layout.addWidget(QLabel("状态:"))
        self.monitor_status_label = BodyLabel("未运行")
        self.monitor_status_label.setStyleSheet("color: gray;")
        control_layout.addWidget(self.monitor_status_label)
        
        control_layout.addStretch()
        
        # 监控日志卡片
        log_card = CardWidget()
        log_layout = QVBoxLayout(log_card)
        
        # 监控日志标题
        log_layout.addWidget(SubtitleLabel("监控日志"))
        
        # 监控日志表格
        self.log_table = QTableWidget()
        self.log_table.setColumnCount(4)
        self.log_table.setHorizontalHeaderLabels(["时间", "条件", "状态", "详情"])
        self.log_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.log_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.log_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.log_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        
        # 添加示例日志数据
        self.log_table.setRowCount(0)  # 初始为空
        
        log_layout.addWidget(self.log_table)
        
        # 添加卡片到标签页布局
        layout.addWidget(control_card)
        layout.addWidget(log_card)
        
        # 连接信号槽
        self.start_monitor_button.clicked.connect(self._on_start_monitor_clicked)
        self.stop_monitor_button.clicked.connect(self._on_stop_monitor_clicked)
    
    def _on_add_color_condition(self):
        """添加颜色条件按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        InfoBar.success(
            title="功能开发中",
            content="添加颜色条件功能正在开发中",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_add_text_condition(self):
        """添加文本条件按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        InfoBar.success(
            title="功能开发中",
            content="添加文本条件功能正在开发中",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_add_time_condition(self):
        """添加时间条件按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        InfoBar.success(
            title="功能开发中",
            content="添加时间条件功能正在开发中",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_add_composite_clicked(self):
        """添加组合按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        item = QListWidgetItem(f"新组合 {self.composite_list.count() + 1}")
        item.setIcon(FIF.FLAG.icon())
        self.composite_list.addItem(item)
        self.composite_list.setCurrentItem(item)
        
        # 清空表单
        self.composite_name_edit.setText(item.text())
        self.composite_type_combo.setCurrentIndex(0)
        
        # 显示信息条
        InfoBar.success(
            title="已添加新组合",
            content="请编辑组合详情并保存",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_add_condition_to_composite(self):
        """向组合添加条件按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        InfoBar.success(
            title="功能开发中",
            content="添加条件到组合功能正在开发中",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_save_composite_clicked(self):
        """保存组合按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        current_item = self.composite_list.currentItem()
        if current_item:
            current_item.setText(self.composite_name_edit.text())
            
            # 显示信息条
            InfoBar.success(
                title="保存成功",
                content="条件组合信息已更新",
                parent=self,
                position=InfoBarPosition.TOP,
                duration=3000
            )
        else:
            InfoBar.warning(
                title="保存失败",
                content="请先选择一个条件组合",
                parent=self,
                position=InfoBarPosition.TOP,
                duration=3000
            )
    
    def _on_delete_composite_clicked(self):
        """删除组合按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        current_row = self.composite_list.currentRow()
        if current_row >= 0:
            self.composite_list.takeItem(current_row)
            
            # 显示信息条
            InfoBar.information(
                title="删除成功",
                content="条件组合已被删除",
                parent=self,
                position=InfoBarPosition.TOP,
                duration=3000
            )
        else:
            InfoBar.warning(
                title="删除失败",
                content="请先选择一个条件组合",
                parent=self,
                position=InfoBarPosition.TOP,
                duration=3000
            )
    
    def _on_composite_selected(self, current, previous):
        """组合选择事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        if current:
            self.composite_name_edit.setText(current.text())
            self.composite_type_combo.setCurrentIndex(self.composite_list.row(current) % 2)  # 模拟不同类型
    
    def _on_start_monitor_clicked(self):
        """开始监控按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        self.start_monitor_button.setEnabled(False)
        self.stop_monitor_button.setEnabled(True)
        self.monitor_status_label.setText("正在运行")
        self.monitor_status_label.setStyleSheet("color: green;")
        
        # 添加一条日志
        row_count = self.log_table.rowCount()
        self.log_table.insertRow(row_count)
        
        self.log_table.setItem(row_count, 0, QTableWidgetItem("2023-05-24 14:30:00"))
        self.log_table.setItem(row_count, 1, QTableWidgetItem("系统"))
        self.log_table.setItem(row_count, 2, QTableWidgetItem("信息"))
        self.log_table.setItem(row_count, 3, QTableWidgetItem("条件监控已启动"))
        
        # 显示信息条
        InfoBar.success(
            title="监控已启动",
            content="条件监控功能已启动",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        )
    
    def _on_stop_monitor_clicked(self):
        """停止监控按钮点击事件"""
        # 这里只是UI演示，实际功能将在控制器中实现
        self.start_monitor_button.setEnabled(True)
        self.stop_monitor_button.setEnabled(False)
        self.monitor_status_label.setText("未运行")
        self.monitor_status_label.setStyleSheet("color: gray;")
        
        # 添加一条日志
        row_count = self.log_table.rowCount()
        self.log_table.insertRow(row_count)
        
        self.log_table.setItem(row_count, 0, QTableWidgetItem("2023-05-24 14:35:00"))
        self.log_table.setItem(row_count, 1, QTableWidgetItem("系统"))
        self.log_table.setItem(row_count, 2, QTableWidgetItem("信息"))
        self.log_table.setItem(row_count, 3, QTableWidgetItem("条件监控已停止"))
        
        # 显示信息条
        InfoBar.information(
            title="监控已停止",
            content="条件监控功能已停止",
            parent=self,
            position=InfoBarPosition.TOP,
            duration=3000
        ) 