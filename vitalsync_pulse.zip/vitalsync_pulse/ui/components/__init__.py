"""
UI组件模块

这个模块包含了应用程序使用的可复用UI组件，如选择框、自定义控件等。
"""

# 将来会从子模块导入
# from vitalsync_pulse.ui.components.selection_box import TransparentSelectionBox
# from vitalsync_pulse.ui.components.custom_widgets import CustomWidget 