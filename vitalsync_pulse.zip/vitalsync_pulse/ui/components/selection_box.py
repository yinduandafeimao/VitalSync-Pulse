#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
透明选择框组件

这个模块提供了透明的选择框组件，用于在屏幕上选择区域。
包括基本的TransparentSelectionBox和基于FluentUI风格的FluentSelectionBox。
"""

import sys
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QVBoxLayout,
                            QRubberBand, QMainWindow, QDialog)
from PyQt5.QtCore import Qt, QRect, QPoint, QSize, pyqtSignal, QObject
from PyQt5.QtGui import QPainter, QPen, QColor, QScreen

# 尝试导入qfluentwidgets，如果不可用则提供备用方案
try:
    from qfluentwidgets import InfoBar, InfoBarPosition, TeachingTip, ToolTipPosition
    QFLUENTWIDGETS_AVAILABLE = True
except ImportError:
    QFLUENTWIDGETS_AVAILABLE = False
    print("警告: qfluentwidgets库未安装，将使用基本选择框")

class SelectionSignals(QObject):
    """选择框信号类"""
    selection_completed = pyqtSignal(QRect)
    selection_canceled = pyqtSignal()

class TransparentSelectionBox(QWidget):
    """透明选择框组件
    
    这个组件提供了一个透明的选择框，用于在屏幕上选择区域。
    用户可以通过鼠标拖动来选择一个矩形区域，选择完成后会发出信号。
    
    属性:
        signals: 选择框信号对象
        origin: 选择起点
        rubber_band: 橡皮筋选择框
        is_selecting: 是否正在选择
    """
    
    def __init__(self, parent=None):
        """初始化透明选择框
        
        参数:
            parent: 父窗口
        """
        super().__init__(parent)
        
        # 设置窗口属性
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setCursor(Qt.CrossCursor)
        
        # 设置全屏
        self.setGeometry(QApplication.desktop().availableGeometry())
        
        # 初始化变量
        self.signals = SelectionSignals()
        self.origin = QPoint()
        self.rubber_band = QRubberBand(QRubberBand.Rectangle, self)
        self.is_selecting = False
        
        # 设置橡皮筋样式
        self.rubber_band.setStyleSheet("""
            background-color: rgba(0, 120, 215, 0.3);
            border: 1px solid rgba(0, 120, 215, 0.8);
        """)
        
        # 添加说明标签
        self.info_label = QLabel("按住鼠标左键拖动选择区域，按ESC取消", self)
        self.info_label.setStyleSheet("""
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 8px;
            border-radius: 4px;
        """)
        self.info_label.setAlignment(Qt.AlignCenter)
        self.info_label.adjustSize()
        self.info_label.move(
            (self.width() - self.info_label.width()) // 2,
            self.height() - self.info_label.height() - 50
        )
        
        # 显示坐标信息的标签
        self.coords_label = QLabel(self)
        self.coords_label.setStyleSheet("""
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
        """)
        self.coords_label.hide()
    
    def paintEvent(self, event):
        """绘制事件
        
        绘制半透明背景和网格线
        """
        painter = QPainter(self)
        
        # 设置半透明背景
        painter.fillRect(self.rect(), QColor(0, 0, 0, 100))
        
        # 如果正在选择，绘制网格线
        if self.is_selecting and not self.rubber_band.geometry().isEmpty():
            rect = self.rubber_band.geometry()
            
            # 绘制水平和垂直中心线
            painter.setPen(QPen(QColor(255, 255, 255, 150), 1, Qt.DashLine))
            center_x = rect.x() + rect.width() // 2
            center_y = rect.y() + rect.height() // 2
            
            # 水平中心线
            painter.drawLine(rect.x(), center_y, rect.x() + rect.width(), center_y)
            # 垂直中心线
            painter.drawLine(center_x, rect.y(), center_x, rect.y() + rect.height())
        
    def keyPressEvent(self, event):
        """按键事件处理
        
        ESC键取消选择
        """
        if event.key() == Qt.Key_Escape:
            self.signals.selection_canceled.emit()
            self.close()
        super().keyPressEvent(event)
    
    def mousePressEvent(self, event):
        """鼠标按下事件处理
        
        开始选择区域
        """
        if event.button() == Qt.LeftButton:
            self.is_selecting = True
            self.origin = event.pos()
            self.rubber_band.setGeometry(QRect(self.origin, QSize()))
            self.rubber_band.show()
            
            # 显示坐标信息
            self.update_coords_label(event.pos())
            self.coords_label.show()
    
    def mouseMoveEvent(self, event):
        """鼠标移动事件处理
        
        更新选择区域
        """
        if self.is_selecting:
            rect = QRect(self.origin, event.pos()).normalized()
            self.rubber_band.setGeometry(rect)
            
            # 更新坐标信息
            self.update_coords_label(event.pos())
            
            # 重绘以更新网格线
            self.update()
    
    def mouseReleaseEvent(self, event):
        """鼠标释放事件处理
        
        完成选择区域
        """
        if event.button() == Qt.LeftButton and self.is_selecting:
            self.is_selecting = False
            
            # 获取选择的区域
            rect = self.rubber_band.geometry()
            
            # 如果区域有效，发出信号
            if rect.width() > 10 and rect.height() > 10:
                self.signals.selection_completed.emit(rect)
                self.close()
            else:
                # 区域太小，重置选择
                self.rubber_band.hide()
                self.coords_label.hide()
    
    def update_coords_label(self, pos):
        """更新坐标信息标签
        
        参数:
            pos: 当前鼠标位置
        """
        rect = QRect(self.origin, pos).normalized()
        text = f"位置: ({rect.x()}, {rect.y()}) 大小: {rect.width()} × {rect.height()}"
        self.coords_label.setText(text)
        self.coords_label.adjustSize()
        
        # 根据选择框位置调整标签位置
        if rect.y() > 50:
            # 在选择框上方显示
            self.coords_label.move(
                rect.x() + (rect.width() - self.coords_label.width()) // 2,
                rect.y() - self.coords_label.height() - 5
            )
        else:
            # 在选择框下方显示
            self.coords_label.move(
                rect.x() + (rect.width() - self.coords_label.width()) // 2,
                rect.y() + rect.height() + 5
            )

class FluentSelectionBox(QDialog):
    """基于FluentUI风格的选择框
    
    这个组件提供了一个FluentUI风格的选择框，用于在屏幕上选择区域。
    用户可以通过鼠标拖动来选择一个矩形区域，按Enter确认或ESC取消。
    
    属性:
        callback: 选择完成回调函数
        start_point: 选择起点
        end_point: 选择终点
        dragging: 是否正在拖动
        selected_rect: 已选择的矩形区域
        is_capturing: 是否正在截图
    """
    def __init__(self, parent=None, callback=None):
        """初始化FluentUI风格选择框
        
        参数:
            parent: 父窗口
            callback: 选择完成回调函数，接收一个QRect参数
        """
        super().__init__(parent)
        self.callback = callback
        self.start_point = QPoint()
        self.end_point = QPoint()
        self.dragging = False
        self.selected_rect = None
        self.is_capturing = False  # 标记是否正在截图
        
        # 设置窗口属性
        self.setWindowFlags(
            Qt.FramelessWindowHint  # 无边框
            | Qt.WindowStaysOnTopHint  # 置顶
            | Qt.Tool  # 隐藏任务栏图标
        )
        self.setAttribute(Qt.WA_TranslucentBackground)  # 透明背景
        self.setWindowModality(Qt.ApplicationModal)  # 应用模态
        
        # 获取屏幕尺寸并设置全屏
        self.screen_rect = QApplication.primaryScreen().geometry()
        self.setGeometry(self.screen_rect)
        
        # 添加指导标签
        self.instruction_label = QLabel(self)
        self.instruction_label.setStyleSheet(
            "background-color: rgba(0, 0, 0, 150); color: white; padding: 10px; border-radius: 5px;"
        )
        self.instruction_label.setAlignment(Qt.AlignCenter)
        self.instruction_label.move(20, 20)
        self.showInstructions("请拖动鼠标选择区域，按Enter确认，按ESC取消")

    def showInstructions(self, text):
        """显示操作指导提示"""
        self.instruction_label.setText(text)
        self.instruction_label.adjustSize()
        self.instruction_label.show()
    
    def mousePressEvent(self, event):
        """鼠标按下事件处理"""
        if event.button() == Qt.LeftButton:
            self.start_point = event.pos()
            self.end_point = self.start_point
            self.dragging = True
            self.update()

    def mouseMoveEvent(self, event):
        """鼠标移动事件处理"""
        if self.dragging:
            self.end_point = event.pos()
            self.update()

    def mouseReleaseEvent(self, event):
        """鼠标释放事件处理"""
        if event.button() == Qt.LeftButton and self.dragging:
            self.dragging = False
            self.selected_rect = self.getSelectedRect()
            
            # 显示选择的坐标信息
            if self.selected_rect.isValid() and self.selected_rect.width() > 5 and self.selected_rect.height() > 5:
                rect_info = f"位置: ({self.selected_rect.x()}, {self.selected_rect.y()}), " \
                           f"大小: {self.selected_rect.width()}x{self.selected_rect.height()}"
                self.showInstructions(f"已选择区域: {rect_info}\n按Enter确认，按ESC取消")
            
            self.update()

    def paintEvent(self, event):
        """绘制事件处理"""
        painter = QPainter(self)
        
        # 设置半透明背景
        painter.fillRect(self.rect(), QColor(0, 0, 0, 50))
        
        # 如果有选择区域，绘制选择框
        if self.selected_rect and self.selected_rect.isValid():
            # 清除选择区域的半透明背景
            painter.save()
            eraser = QPainter(self)
            eraser.setCompositionMode(QPainter.CompositionMode_Clear)
            eraser.fillRect(self.selected_rect, Qt.transparent)
            painter.restore()
            
            # 绘制边框，只在非截图模式下显示
            if not self.is_capturing:
                # 绿色边框
                pen = QPen(QColor(0, 168, 174))  # 使用和VitalSync相同的青绿色
                pen.setWidth(2)
                painter.setPen(pen)
                painter.drawRect(self.selected_rect.adjusted(-2, -2, 2, 2))
                
                # 在四角绘制控制点
                control_points = [
                    QRect(self.selected_rect.left()-4, self.selected_rect.top()-4, 8, 8),
                    QRect(self.selected_rect.right()-4, self.selected_rect.top()-4, 8, 8),
                    QRect(self.selected_rect.left()-4, self.selected_rect.bottom()-4, 8, 8),
                    QRect(self.selected_rect.right()-4, self.selected_rect.bottom()-4, 8, 8)
                ]
                
                painter.setBrush(QColor(0, 168, 174))
                for point in control_points:
                    painter.drawRect(point)
        
        # 如果正在拖动，绘制选择框
        elif self.dragging:
            temp_rect = self.getSelectedRect()
            if temp_rect.isValid():
                # 绘制虚线边框和半透明背景
                painter.setPen(QPen(QColor(255, 255, 255), 1, Qt.DashLine))
                painter.setBrush(QColor(255, 255, 255, 30))
                painter.drawRect(temp_rect)
                
                # 显示尺寸信息
                size_text = f"{temp_rect.width()} x {temp_rect.height()}"
                painter.setPen(Qt.white)
                painter.drawText(temp_rect.center(), size_text)

    def getSelectedRect(self):
        """获取选择的矩形区域(处理反向拖动)"""
        return QRect(
            min(self.start_point.x(), self.end_point.x()),
            min(self.start_point.y(), self.end_point.y()),
            abs(self.start_point.x() - self.end_point.x()),
            abs(self.start_point.y() - self.end_point.y())
        )
    
    def getSelectedImage(self):
        """获取选择区域的截图"""
        if not self.selected_rect or not self.selected_rect.isValid():
            return None
            
        try:
            # 标记开始截图
            self.is_capturing = True
            self.update()  # 刷新显示，隐藏边框
            
            # 等待重绘完成
            QApplication.processEvents()
            
            # 截取选定区域
            screen = QApplication.primaryScreen()
            screenshot = screen.grabWindow(
                0, 
                self.selected_rect.x(), 
                self.selected_rect.y(), 
                self.selected_rect.width(), 
                self.selected_rect.height()
            )
            
            # 转换为numpy数组
            image = screenshot.toImage()
            buffer = image.bits().tobytes()
            
            import numpy as np
            import cv2
            img_array = np.frombuffer(buffer, dtype=np.uint8).reshape(
                (image.height(), image.width(), 4))
            img_array = cv2.cvtColor(img_array, cv2.COLOR_BGRA2BGR)
            
            # 恢复显示边框
            self.is_capturing = False
            self.update()
            
            return img_array
        except Exception as e:
            print(f"截图失败: {str(e)}")
            self.is_capturing = False
            self.update()
            return None
    
    def keyPressEvent(self, event):
        """按键事件处理"""
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            # 确认选择
            if self.selected_rect and self.selected_rect.width() > 5 and self.selected_rect.height() > 5:
                # 调用回调函数
                if self.callback:
                    self.callback(self.selected_rect)
                self.accept()
        elif event.key() == Qt.Key_Escape:
            # 取消选择
            self.reject()

def show_selection_box(callback=None, cancel_callback=None):
    """显示选择框
    
    参数:
        callback: 选择完成回调函数，接收一个QRect参数
        cancel_callback: 取消选择回调函数
    
    返回:
        如果使用FluentSelectionBox并成功选择，返回True
        如果使用TransparentSelectionBox，返回None
    """
    # 如果FluentUI组件可用，优先使用FluentSelectionBox
    if QFLUENTWIDGETS_AVAILABLE:
        def on_selection(rect):
            if callback:
                callback(rect)
        
        dialog = FluentSelectionBox(callback=on_selection)
        result = dialog.exec_()
        return result == QDialog.Accepted
    else:
        # 使用原始的TransparentSelectionBox
        app = QApplication.instance() or QApplication(sys.argv)
        
        selection_box = TransparentSelectionBox()
        
        if callback:
            selection_box.signals.selection_completed.connect(callback)
        if cancel_callback:
            selection_box.signals.selection_canceled.connect(cancel_callback)
        
        selection_box.show()
        return None

if __name__ == "__main__":
    # 测试代码
    app = QApplication(sys.argv)
    
    def on_selection(rect):
        print(f"选择区域: ({rect.x()}, {rect.y()}, {rect.width()}, {rect.height()})")
    
    def on_cancel():
        print("选择已取消")
    
    selection_box = show_selection_box(on_selection, on_cancel)
    
    sys.exit(app.exec_()) 