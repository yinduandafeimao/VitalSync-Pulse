# VitalSync Pulse 开发者指南

本指南为 VitalSync Pulse 项目的开发者提供参考，包括项目结构、编码规范、开发流程和测试方法。

## 1. 项目概述

VitalSync Pulse 是一个使用 PyQt5 和 QFluentWidgets 构建的桌面应用程序，用于游戏辅助工具，提供了健康监控、技能循环和条件触发等功能。

项目采用 MVC (Model-View-Controller) 架构，清晰地分离了数据、用户界面和业务逻辑。

## 2. 开发环境设置

### 2.1 依赖项

主要依赖项包括：

- Python 3.8 或更高版本
- PyQt5
- QFluentWidgets
- OpenCV (用于屏幕捕获和图像处理)
- Numpy
- PyTesseract (用于文本识别)

### 2.2 安装开发环境

1. 克隆仓库：
   ```bash
   git clone https://github.com/your-username/VitalSync-Pulse.git
   cd VitalSync-Pulse
   ```

2. 创建虚拟环境（推荐）：
   ```bash
   python -m venv venv
   # Windows
   venv\Scripts\activate
   # Linux/Mac
   source venv/bin/activate
   ```

3. 安装依赖：
   ```bash
   pip install -r requirements.txt
   ```

### 2.3 IDE 推荐

推荐使用 Visual Studio Code、PyCharm 或任何支持 Python 的 IDE。对于 Visual Studio Code，建议安装以下扩展：

- Python
- Pylance
- Python Test Explorer
- Qt for Python

## 3. 项目结构

```
vitalsync_pulse/
├── config/               # 配置文件目录
├── core/                 # 核心功能
│   ├── config/           # 配置管理
│   └── controllers/      # 控制器
├── modules/              # 功能模块
│   ├── health_monitoring/ # 健康监控模块
│   ├── skill_system/     # 技能系统模块
│   └── condition_system/ # 条件系统模块
├── resources/            # 资源文件
├── tests/                # 单元测试
├── ui/                   # 用户界面
│   ├── components/       # UI组件
│   ├── dialogs/          # 对话框
│   ├── views/            # 页面视图
│   └── widgets/          # 自定义控件
├── docs/                 # 文档
├── main.py               # 程序入口
└── run_tests.py          # 测试运行脚本
```

## 4. MVC 架构说明

### 4.1 模型 (Model)

- 位于 `modules/` 目录中
- 包含所有业务逻辑和数据处理
- 不依赖于视图或控制器
- 负责数据的持久化和检索

### 4.2 视图 (View)

- 位于 `ui/views/` 目录中
- 负责用户界面的展示
- 不直接与模型通信，通过控制器进行交互
- 通过信号槽机制发送用户操作事件

### 4.3 控制器 (Controller)

- 位于 `core/controllers/` 目录中
- 连接模型和视图
- 处理用户输入
- 更新模型和视图

## 5. 开发指南

### 5.1 添加新功能

添加新功能需要按照以下步骤进行：

1. **创建或修改模型**：
   - 在相应的模块目录中添加/修改模型类
   - 确保模型不依赖于视图或控制器
   - 添加必要的数据持久化方法

2. **创建或修改视图**：
   - 在 `ui/views/` 目录中添加/修改视图类
   - 确保视图不直接与模型交互
   - 为所有用户操作定义信号

3. **创建或修改控制器**：
   - 在 `core/controllers/` 目录中添加/修改控制器类
   - 继承 `BaseController` 基类
   - 实现 `connect_view_model` 和 `disconnect_view_model` 方法
   - 处理视图信号并更新模型和视图

4. **更新应用程序控制器**：
   - 在 `app_controller.py` 中集成新控制器
   - 更新 `setup_controllers` 方法

5. **添加单元测试**：
   - 在 `tests/` 目录中添加新的测试类
   - 更新 `test_suite.py` 包含新的测试
   - 运行测试确保功能正常

### 5.2 编码规范

- 遵循 PEP 8 编码风格
- 使用 4 空格缩进
- 所有类和方法添加文档字符串
- 使用有意义的变量和函数名称
- 模块、类和方法的命名：
  - 模块名使用小写字母，单词之间用下划线分隔
  - 类名使用 CamelCase 风格
  - 方法和函数名使用小写字母，单词之间用下划线分隔

### 5.3 错误处理

- 使用 try-except 块捕获预期的异常
- 使用日志记录错误，而不是简单的 print 语句
- 向用户显示友好的错误消息，使用 `InfoBar` 组件

## 6. 测试指南

### 6.1 单元测试

所有功能都应该有单元测试。使用标准的 `unittest` 框架进行测试。

测试文件命名为 `test_*.py`，测试类命名为 `Test*`，测试方法命名为 `test_*`。

示例：

```python
import unittest

class TestHealthMonitorController(unittest.TestCase):
    def setUp(self):
        # 设置测试环境
        pass
        
    def test_start_monitoring(self):
        # 测试开始监控功能
        pass
        
    def tearDown(self):
        # 清理测试环境
        pass
```

### 6.2 运行测试

有两种方式运行测试：

1. 运行所有测试：
   ```bash
   python vitalsync_pulse/run_tests.py
   ```

2. 运行特定测试：
   ```bash
   python -m unittest vitalsync_pulse/tests/test_health_monitor_controller.py
   ```

### 6.3 模拟 (Mocking)

在测试控制器时，应该使用模拟对象替代真实的视图和模型，以隔离被测组件。

示例：

```python
from unittest.mock import MagicMock

# 创建模拟视图和模型
mock_view = MagicMock()
mock_model = MagicMock()

# 创建控制器
controller = HealthMonitorController(mock_view, mock_model)

# 测试方法调用
controller.start_monitoring()
mock_model.start_monitoring.assert_called_once()
```

## 7. 调试技巧

### 7.1 日志记录

使用 Python 标准库的 `logging` 模块记录日志：

```python
import logging

# 配置日志记录
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# 记录日志
logger.debug("Debug message")
logger.info("Info message")
logger.warning("Warning message")
logger.error("Error message")
```

### 7.2 PyQt 调试

- 使用 Qt Creator 设计 UI
- 使用 QDebug 记录 Qt 相关信息
- 使用 Qt Designer 查看和修改 UI 文件

## 8. 发布流程

### 8.1 版本控制

- 使用语义化版本控制 (Semantic Versioning)
- 版本号格式：MAJOR.MINOR.PATCH
  - MAJOR: 不兼容的 API 更改
  - MINOR: 向后兼容的功能新增
  - PATCH: 向后兼容的错误修复

### 8.2 打包应用

使用 PyInstaller 打包应用程序：

```bash
pyinstaller --onefile --windowed --icon=resources/icons/app_icon.ico main.py
```

### 8.3 发布检查清单

- 所有测试通过
- 版本号更新
- 更新日志已编写
- 文档已更新
- 发布说明已准备

## 9. 贡献指南

我们欢迎并感谢任何形式的贡献。以下是贡献的流程：

1. Fork 项目仓库
2. 创建新的分支（功能分支或修复分支）
3. 提交更改
4. 推送分支
5. 创建 Pull Request

## 10. 常见问题

### 10.1 安装问题

**Q: 安装依赖时出现错误？**
A: 确保您安装了正确版本的 Python 和所有必要的系统依赖项。

### 10.2 运行问题

**Q: 应用程序崩溃？**
A: 检查日志文件中的错误消息。

### 10.3 开发问题

**Q: 如何调试 PyQt 应用程序？**
A: 使用 Python 调试器和日志记录。

## 11. 资源链接

- [PyQt5 文档](https://www.riverbankcomputing.com/static/Docs/PyQt5/)
- [QFluentWidgets 文档](https://github.com/zhiyiYo/PyQt-Fluent-Widgets)
- [Python unittest 文档](https://docs.python.org/3/library/unittest.html)
- [PyInstaller 文档](https://pyinstaller.org/en/stable/) 