"""
VitalSync Pulse - 游戏辅助工具

这个包包含了VitalSync Pulse的所有功能模块，用于监控游戏中队友的血量状态
并提供自动选择低血量队友的功能。
"""

__version__ = '1.0.0'
__author__ = 'VitalSync Team' 