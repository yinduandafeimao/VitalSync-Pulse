#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
条件触发控制器单元测试

这个模块包含对条件触发控制器的单元测试，确保其正确运行。
"""

import unittest
from unittest.mock import MagicMock, patch

from PyQt5.QtWidgets import QApplication, QTableWidgetItem, QListWidgetItem
from PyQt5.QtCore import Qt
import sys

from vitalsync_pulse.core.controllers.condition_trigger_controller import ConditionTriggerController
from vitalsync_pulse.modules.condition_system.condition_models import Condition, ConditionParameter, ConditionReference
from vitalsync_pulse.ui.views.condition_trigger_view import ConditionTriggerView


class TestConditionTriggerController(unittest.TestCase):
    """条件触发控制器测试类"""

    @classmethod
    def setUpClass(cls):
        """在所有测试之前设置环境"""
        # 创建QApplication实例（如果尚未创建）
        if not QApplication.instance():
            cls.app = QApplication(sys.argv)
        else:
            cls.app = QApplication.instance()

    def setUp(self):
        """每个测试前的设置"""
        # 创建模拟的视图和模型
        self.mock_view = MagicMock(spec=ConditionTriggerView)
        self.mock_model = MagicMock()  # 这里可以使用一个通用的Mock，因为ConditionSystem可能没有明确的接口

        # 创建控制器
        self.controller = ConditionTriggerController(self.mock_view, self.mock_model)

        # 模拟一些条件数据
        self.mock_color_condition = MagicMock(spec=Condition)
        self.mock_color_condition.id = "color1"
        self.mock_color_condition.name = "测试颜色条件"
        self.mock_color_condition.condition_type = "color"
        self.mock_color_condition.enabled = True
        self.mock_color_condition.parameters = []
        self.mock_color_condition.sub_conditions = []
        self.mock_color_condition.get_parameter = MagicMock(return_value=None)

        self.mock_composite_condition = MagicMock(spec=Condition)
        self.mock_composite_condition.id = "combo1"
        self.mock_composite_condition.name = "测试复合条件"
        self.mock_composite_condition.condition_type = "combo"
        self.mock_composite_condition.enabled = True
        self.mock_composite_condition.parameters = []
        self.mock_composite_condition.sub_conditions = []
        
        # 模拟operator参数
        operator_param = MagicMock(spec=ConditionParameter)
        operator_param.name = "operator"
        operator_param.value = "AND"
        self.mock_composite_condition.get_parameter = MagicMock(return_value=operator_param)

        # 设置Condition.load和Condition.load_all的模拟返回值
        self.condition_load_patcher = patch('vitalsync_pulse.modules.condition_system.condition_models.Condition.load')
        self.mock_condition_load = self.condition_load_patcher.start()
        self.mock_condition_load.side_effect = lambda id: {
            "color1": self.mock_color_condition,
            "combo1": self.mock_composite_condition
        }.get(id)

        self.condition_load_all_patcher = patch('vitalsync_pulse.modules.condition_system.condition_models.Condition.load_all')
        self.mock_condition_load_all = self.condition_load_all_patcher.start()
        self.mock_condition_load_all.return_value = {
            "color1": self.mock_color_condition,
            "combo1": self.mock_composite_condition
        }

        # 设置Condition.delete的模拟返回值
        self.condition_delete_patcher = patch('vitalsync_pulse.modules.condition_system.condition_models.Condition.delete')
        self.mock_condition_delete = self.condition_delete_patcher.start()
        self.mock_condition_delete.return_value = True

    def test_initialization(self):
        """测试控制器初始化"""
        # 测试视图和模型是否正确分配
        self.assertEqual(self.controller.view, self.mock_view)
        self.assertEqual(self.controller.model, self.mock_model)
        self.assertIsNone(self.controller.current_condition)
        self.assertIsNone(self.controller.current_composite)
        self.assertFalse(self.controller.monitoring_active)
        self.assertEqual(self.controller.monitoring_results, {})

    def test_connect_view_model(self):
        """测试连接视图和模型"""
        # 调用连接方法
        self.controller.connect_view_model()

        # 验证视图的信号是否已连接到控制器的槽函数
        self.mock_view.tab_widget.currentChanged.connect.assert_called()
        self.mock_view.add_color_condition_btn.clicked.connect.assert_called()
        self.mock_view.add_text_condition_btn.clicked.connect.assert_called()
        self.mock_view.add_time_condition_btn.clicked.connect.assert_called()
        self.mock_view.add_composite_button.clicked.connect.assert_called()
        self.mock_view.composite_list.currentItemChanged.connect.assert_called()
        self.mock_view.start_monitor_button.clicked.connect.assert_called()
        self.mock_view.stop_monitor_button.clicked.connect.assert_called()

    def test_disconnect_view_model(self):
        """测试断开视图和模型连接"""
        # 首先连接
        self.controller.connect_view_model()
        
        # 然后断开连接
        self.controller.disconnect_view_model()

        # 验证视图的信号是否已断开连接
        self.mock_view.tab_widget.currentChanged.disconnect.assert_called()
        self.mock_view.add_color_condition_btn.clicked.disconnect.assert_called()
        self.mock_view.add_text_condition_btn.clicked.disconnect.assert_called()
        self.mock_view.add_time_condition_btn.clicked.disconnect.assert_called()
        self.mock_view.add_composite_button.clicked.disconnect.assert_called()
        self.mock_view.composite_list.currentItemChanged.disconnect.assert_called()
        self.mock_view.start_monitor_button.clicked.disconnect.assert_called()
        self.mock_view.stop_monitor_button.clicked.disconnect.assert_called()

    def test_load_conditions(self):
        """测试加载条件列表"""
        # 调用加载条件方法
        self.controller._load_conditions()

        # 验证是否清空了条件表格
        self.mock_view.condition_table.setRowCount.assert_called_with(0)
        
        # 验证是否加载了所有条件
        self.mock_condition_load_all.assert_called_once()
        
        # 验证是否添加了条件项到表格
        self.mock_view.condition_table.insertRow.assert_called()
        self.mock_view.condition_table.setItem.assert_called()

    def test_load_composites(self):
        """测试加载复合条件列表"""
        # 调用加载复合条件方法
        self.controller._load_composites()

        # 验证是否清空了复合条件列表
        self.mock_view.composite_list.clear.assert_called_once()
        
        # 验证是否加载了所有条件
        self.mock_condition_load_all.assert_called_once()
        
        # 验证是否添加了复合条件项到列表
        self.mock_view.composite_list.addItem.assert_called()

    def test_get_condition_type_display(self):
        """测试获取条件类型显示名称"""
        # 测试各种条件类型
        self.assertEqual(self.controller._get_condition_type_display("color"), "Color Condition")
        self.assertEqual(self.controller._get_condition_type_display("text"), "Text Condition")
        self.assertEqual(self.controller._get_condition_type_display("time"), "Time Condition")
        self.assertEqual(self.controller._get_condition_type_display("combo"), "Composite Condition")
        self.assertEqual(self.controller._get_condition_type_display("unknown"), "unknown")  # 未知类型应返回原值

    def test_on_composite_selected(self):
        """测试选择复合条件"""
        # 创建模拟的QListWidgetItem
        mock_item = MagicMock(spec=QListWidgetItem)
        mock_item.data.return_value = "combo1"

        # 调用选择复合条件方法
        self.controller._on_composite_selected(mock_item, None)

        # 验证是否加载了选定的复合条件
        self.mock_condition_load.assert_called_once_with("combo1")
        
        # 验证是否更新了当前复合条件
        self.assertEqual(self.controller.current_composite, self.mock_composite_condition)
        
        # 验证是否填充了复合条件表单
        self.mock_view.composite_name_edit.setText.assert_called_with(self.mock_composite_condition.name)
        self.mock_view.composite_type_combo.setCurrentIndex.assert_called()

        # 验证是否清空并重新填充了条件流布局
        self.mock_view.conditions_flow_layout.count.assert_called()
        self.mock_condition_load_all.assert_called()

    def test_on_add_color_condition(self):
        """测试添加颜色条件"""
        # 模拟Condition构造函数和save方法
        with patch('vitalsync_pulse.modules.condition_system.condition_models.Condition', autospec=True) as mock_condition_class:
            # 设置mock返回值
            mock_new_condition = MagicMock(spec=Condition)
            mock_new_condition.id = "new_color"
            mock_condition_class.return_value = mock_new_condition
            
            # 模拟点击添加颜色条件按钮
            self.controller._on_add_color_condition()
            
            # 验证是否创建了新颜色条件
            mock_condition_class.assert_called_once_with("New Color Condition", "color")
            
            # 验证是否添加了默认参数
            mock_new_condition.add_parameter.assert_called()
            
            # 验证是否保存了新条件
            mock_new_condition.save.assert_called_once()
            
            # 验证是否重新加载了条件列表
            self.mock_condition_load_all.assert_called()

    def test_on_start_monitor_clicked(self):
        """测试开始监控按钮点击"""
        # 模拟_start_monitoring方法和_initialize_monitoring_table方法
        with patch.object(self.controller, '_start_monitoring') as mock_start_monitoring, \
             patch.object(self.controller, '_initialize_monitoring_table') as mock_init_table:
            
            # 调用开始监控方法
            self.controller._on_start_monitor_clicked()
            
            # 验证监控状态是否更新
            self.assertTrue(self.controller.monitoring_active)
            
            # 验证视图是否更新
            self.mock_view.start_monitor_button.setEnabled.assert_called_with(False)
            self.mock_view.stop_monitor_button.setEnabled.assert_called_with(True)
            self.mock_view.monitor_status_label.setText.assert_called_with("Monitoring Active")
            self.mock_view.monitor_status_label.setStyleSheet.assert_called_with("color: green;")
            
            # 验证是否初始化了监控表格
            mock_init_table.assert_called_once()
            
            # 验证是否启动了监控
            mock_start_monitoring.assert_called_once()

    def test_on_stop_monitor_clicked(self):
        """测试停止监控按钮点击"""
        # 设置监控状态为活动
        self.controller.monitoring_active = True
        
        # 模拟_stop_monitoring方法
        with patch.object(self.controller, '_stop_monitoring') as mock_stop_monitoring:
            
            # 调用停止监控方法
            self.controller._on_stop_monitor_clicked()
            
            # 验证监控状态是否更新
            self.assertFalse(self.controller.monitoring_active)
            
            # 验证视图是否更新
            self.mock_view.start_monitor_button.setEnabled.assert_called_with(True)
            self.mock_view.stop_monitor_button.setEnabled.assert_called_with(False)
            self.mock_view.monitor_status_label.setText.assert_called_with("Monitoring Inactive")
            self.mock_view.monitor_status_label.setStyleSheet.assert_called_with("color: gray;")
            
            # 验证是否停止了监控
            mock_stop_monitoring.assert_called_once()

    def test_delete_condition(self):
        """测试删除条件"""
        # 调用删除条件方法
        self.controller.delete_condition("color1")
        
        # 验证是否删除了条件
        self.mock_condition_delete.assert_called_once_with("color1")
        
        # 验证是否重新加载了条件列表和复合条件列表
        self.mock_condition_load_all.assert_called()

    def tearDown(self):
        """每个测试后的清理"""
        # 停止所有patch
        self.condition_load_patcher.stop()
        self.condition_load_all_patcher.stop()
        self.condition_delete_patcher.stop()
        
        # 断开控制器连接
        self.controller.disconnect_view_model()
        self.controller = None


if __name__ == '__main__':
    unittest.main() 