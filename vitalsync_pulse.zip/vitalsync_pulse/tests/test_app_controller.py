#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
应用程序控制器单元测试

这个模块包含对应用程序控制器的单元测试，确保其正确运行。
"""

import unittest
from unittest.mock import MagicMock, patch

from PyQt5.QtWidgets import QApplication, QWidget
import sys

from vitalsync_pulse.core.controllers.app_controller import AppController
from vitalsync_pulse.core.controllers.health_monitor_controller import HealthMonitorController
from vitalsync_pulse.core.controllers.skill_cycle_controller import SkillCycleController
from vitalsync_pulse.core.controllers.condition_trigger_controller import ConditionTriggerController
from vitalsync_pulse.modules.health_monitoring import HealthMonitor
from vitalsync_pulse.modules.skill_system.skill_models import SkillSystem
from vitalsync_pulse.modules.condition_system.condition_models import ConditionSystem


class TestAppController(unittest.TestCase):
    """应用程序控制器测试类"""

    @classmethod
    def setUpClass(cls):
        """在所有测试之前设置环境"""
        # 创建QApplication实例（如果尚未创建）
        if not QApplication.instance():
            cls.app = QApplication(sys.argv)
        else:
            cls.app = QApplication.instance()

    def setUp(self):
        """每个测试前的设置"""
        # 创建模拟的主窗口
        self.mock_main_window = MagicMock()
        
        # 创建模拟的视图组件
        self.mock_health_view = MagicMock()
        self.mock_skill_view = MagicMock()
        self.mock_condition_view = MagicMock()
        self.mock_settings_view = MagicMock()
        
        # 设置主窗口的视图属性
        self.mock_main_window.health_monitor_interface = MagicMock()
        self.mock_main_window.health_monitor_interface.widget.return_value = self.mock_health_view
        
        self.mock_main_window.skill_cycle_interface = MagicMock()
        self.mock_main_window.skill_cycle_interface.widget.return_value = self.mock_skill_view
        
        self.mock_main_window.condition_trigger_interface = MagicMock()
        self.mock_main_window.condition_trigger_interface.widget.return_value = self.mock_condition_view
        
        self.mock_main_window.settings_interface = MagicMock()
        self.mock_main_window.settings_interface.widget.return_value = self.mock_settings_view
        
        # 设置导航接口
        self.mock_main_window.navigationInterface = MagicMock()
        
        # 模拟模型类
        self.health_monitor_patcher = patch('vitalsync_pulse.modules.health_monitoring.health_monitor.HealthMonitor')
        self.mock_health_monitor_class = self.health_monitor_patcher.start()
        self.mock_health_monitor = MagicMock(spec=HealthMonitor)
        self.mock_health_monitor_class.return_value = self.mock_health_monitor
        
        # 模拟SkillSystem和ConditionSystem
        self.skill_system_patcher = patch('vitalsync_pulse.modules.skill_system.skill_models.SkillSystem')
        self.mock_skill_system_class = self.skill_system_patcher.start()
        self.mock_skill_system = MagicMock(spec=SkillSystem)
        self.mock_skill_system_class.return_value = self.mock_skill_system
        
        self.condition_system_patcher = patch('vitalsync_pulse.modules.condition_system.condition_models.ConditionSystem')
        self.mock_condition_system_class = self.condition_system_patcher.start()
        self.mock_condition_system = MagicMock(spec=ConditionSystem)
        self.mock_condition_system_class.return_value = self.mock_condition_system
        
        # 模拟控制器类
        self.health_controller_patcher = patch('vitalsync_pulse.core.controllers.health_monitor_controller.HealthMonitorController')
        self.mock_health_controller_class = self.health_controller_patcher.start()
        self.mock_health_controller = MagicMock(spec=HealthMonitorController)
        self.mock_health_controller_class.return_value = self.mock_health_controller
        
        self.skill_controller_patcher = patch('vitalsync_pulse.core.controllers.skill_cycle_controller.SkillCycleController')
        self.mock_skill_controller_class = self.skill_controller_patcher.start()
        self.mock_skill_controller = MagicMock(spec=SkillCycleController)
        self.mock_skill_controller_class.return_value = self.mock_skill_controller
        
        self.condition_controller_patcher = patch('vitalsync_pulse.core.controllers.condition_trigger_controller.ConditionTriggerController')
        self.mock_condition_controller_class = self.condition_controller_patcher.start()
        self.mock_condition_controller = MagicMock(spec=ConditionTriggerController)
        self.mock_condition_controller_class.return_value = self.mock_condition_controller
        
        # 创建控制器
        self.controller = AppController(self.mock_main_window)

    def test_initialization(self):
        """测试控制器初始化"""
        # 测试主窗口是否正确分配
        self.assertEqual(self.controller.main_window, self.mock_main_window)
        
        # 测试模型是否正确初始化
        self.mock_health_monitor_class.assert_called_once()
        
        # 测试setup_controllers是否被调用
        # 这个测试可能会被跳过，因为setup_controllers是在__init__中调用的，
        # 并且我们的模拟对象是在setUp方法中设置的，可能在调用之后
        
        # 测试控制器属性是否存在
        self.assertIsNotNone(self.controller.health_monitor_controller)
        self.assertIsNotNone(self.controller.skill_cycle_controller)
        self.assertIsNotNone(self.controller.condition_trigger_controller)

    def test_setup_controllers(self):
        """测试设置控制器"""
        # 重置控制器状态
        self.controller.health_monitor_controller = None
        self.controller.skill_cycle_controller = None
        self.controller.condition_trigger_controller = None
        
        # 调用设置控制器方法
        self.controller.setup_controllers()
        
        # 验证各控制器是否被创建
        self.mock_health_controller_class.assert_called_with(self.mock_health_view, self.mock_health_monitor)
        self.mock_skill_controller_class.assert_called_with(self.mock_skill_view, self.controller.skill_system)
        self.mock_condition_controller_class.assert_called_with(self.mock_condition_view, self.controller.condition_system)
        
        # 验证各控制器的connect_view_model方法是否被调用
        self.mock_health_controller.connect_view_model.assert_called_once()
        self.mock_skill_controller.connect_view_model.assert_called_once()
        self.mock_condition_controller.connect_view_model.assert_called_once()

    def test_disconnect_controllers(self):
        """测试断开控制器连接"""
        # 设置控制器属性
        self.controller.health_monitor_controller = self.mock_health_controller
        self.controller.skill_cycle_controller = self.mock_skill_controller
        self.controller.condition_trigger_controller = self.mock_condition_controller
        
        # 调用断开连接方法
        self.controller.disconnect_controllers()
        
        # 验证各控制器的disconnect_view_model方法是否被调用
        self.mock_health_controller.disconnect_view_model.assert_called_once()
        self.mock_skill_controller.disconnect_view_model.assert_called_once()
        self.mock_condition_controller.disconnect_view_model.assert_called_once()

    def test_on_navigation_switched(self):
        """测试导航切换"""
        # 模拟导航切换到不同页面
        self.controller.on_navigation_switched(0)  # 健康监控页面
        self.controller.on_navigation_switched(1)  # 技能循环页面
        self.controller.on_navigation_switched(2)  # 条件触发页面
        
        # 由于on_navigation_switched方法目前为空，这个测试主要是确保方法不会抛出异常
        # 未来可以添加更多断言来测试实际功能

    def test_shutdown(self):
        """测试关闭操作"""
        # 模拟save_all_data和disconnect_controllers方法
        with patch.object(self.controller, 'save_all_data') as mock_save_all_data, \
             patch.object(self.controller, 'disconnect_controllers') as mock_disconnect_controllers:
            
            # 调用关闭方法
            self.controller.shutdown()
            
            # 验证是否保存了所有数据
            mock_save_all_data.assert_called_once()
            
            # 验证是否断开了所有控制器连接
            mock_disconnect_controllers.assert_called_once()

    def tearDown(self):
        """每个测试后的清理"""
        # 停止所有patch
        self.health_monitor_patcher.stop()
        self.skill_system_patcher.stop()
        self.condition_system_patcher.stop()
        self.health_controller_patcher.stop()
        self.skill_controller_patcher.stop()
        self.condition_controller_patcher.stop()
        
        # 清除控制器
        self.controller = None


if __name__ == '__main__':
    unittest.main() 