#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
健康监控控制器单元测试

这个模块包含对健康监控控制器的单元测试，确保其正确运行。
"""

import unittest
from unittest.mock import MagicMock, patch

from PyQt5.QtWidgets import QApplication
import sys

from vitalsync_pulse.core.controllers.health_monitor_controller import HealthMonitorController
from vitalsync_pulse.modules.health_monitoring import HealthMonitor, Team, TeamMember
from vitalsync_pulse.ui.views.health_monitor_view import HealthMonitorView


class TestHealthMonitorController(unittest.TestCase):
    """健康监控控制器测试类"""

    @classmethod
    def setUpClass(cls):
        """在所有测试之前设置环境"""
        # 创建QApplication实例（如果尚未创建）
        if not QApplication.instance():
            cls.app = QApplication(sys.argv)
        else:
            cls.app = QApplication.instance()

    def setUp(self):
        """每个测试前的设置"""
        # 创建模拟的视图和模型
        self.mock_view = MagicMock(spec=HealthMonitorView)
        self.mock_team = MagicMock(spec=Team)
        self.mock_model = MagicMock(spec=HealthMonitor)
        self.mock_model.team = self.mock_team

        # 创建控制器
        self.controller = HealthMonitorController(self.mock_view, self.mock_model)

    def test_initialization(self):
        """测试控制器初始化"""
        # 测试视图和模型是否正确分配
        self.assertEqual(self.controller.view, self.mock_view)
        self.assertEqual(self.controller.model, self.mock_model)

    def test_connect_view_model(self):
        """测试连接视图和模型"""
        # 调用连接方法
        self.controller.connect_view_model()

        # 验证视图的信号是否已连接到控制器的槽函数
        self.mock_view.start_button.clicked.connect.assert_called()
        self.mock_view.stop_button.clicked.connect.assert_called()
        self.mock_view.add_member_button.clicked.connect.assert_called()

    def test_disconnect_view_model(self):
        """测试断开视图和模型连接"""
        # 首先连接
        self.controller.connect_view_model()
        
        # 然后断开连接
        self.controller.disconnect_view_model()

        # 验证视图的信号是否已断开连接
        self.mock_view.start_button.clicked.disconnect.assert_called()
        self.mock_view.stop_button.clicked.disconnect.assert_called()
        self.mock_view.add_member_button.clicked.disconnect.assert_called()

    def test_start_monitoring(self):
        """测试开始监控功能"""
        # 模拟点击开始按钮
        self.controller._on_start_clicked()

        # 验证模型的开始方法是否被调用
        self.mock_model.start_monitoring.assert_called_once()
        
        # 验证视图是否更新
        self.mock_view.status_label.setText.assert_called_with("监控中...")
        self.mock_view.start_button.setEnabled.assert_called_with(False)
        self.mock_view.stop_button.setEnabled.assert_called_with(True)

    def test_stop_monitoring(self):
        """测试停止监控功能"""
        # 模拟点击停止按钮
        self.controller._on_stop_clicked()

        # 验证模型的停止方法是否被调用
        self.mock_model.stop_monitoring.assert_called_once()
        
        # 验证视图是否更新
        self.mock_view.status_label.setText.assert_called_with("已停止")
        self.mock_view.start_button.setEnabled.assert_called_with(True)
        self.mock_view.stop_button.setEnabled.assert_called_with(False)

    def test_add_team_member(self):
        """测试添加团队成员功能"""
        # 模拟新成员数据
        new_member_name = "测试成员"
        
        # 设置mock返回值
        self.mock_view.get_member_name_input.return_value = new_member_name
        
        # 创建一个模拟的TeamMember对象
        mock_member = MagicMock(spec=TeamMember)
        mock_member.name = new_member_name
        self.mock_team.add_member.return_value = mock_member
        
        # 模拟点击添加成员按钮
        self.controller._on_add_member_clicked()

        # 验证团队的添加成员方法是否被调用
        self.mock_team.add_member.assert_called_once_with(new_member_name)
        
        # 验证视图是否更新以显示新成员
        self.mock_view.add_member_to_ui.assert_called_once()

    def test_update_health_display(self):
        """测试更新健康显示功能"""
        # 模拟成员数据
        mock_member = MagicMock(spec=TeamMember)
        mock_member.name = "测试成员"
        mock_member.health_percentage = 75
        mock_member.is_alive = True
        
        # 模拟信号触发更新
        self.controller.update_health_display(mock_member)
        
        # 验证视图是否更新以显示成员健康状态
        self.mock_view.update_member_health_ui.assert_called_once()

    def tearDown(self):
        """每个测试后的清理"""
        # 断开控制器连接
        self.controller.disconnect_view_model()
        self.controller = None


if __name__ == '__main__':
    unittest.main() 