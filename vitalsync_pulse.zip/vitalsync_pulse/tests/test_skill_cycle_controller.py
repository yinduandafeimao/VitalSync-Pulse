#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
技能循环控制器单元测试

这个模块包含对技能循环控制器的单元测试，确保其正确运行。
"""

import unittest
from unittest.mock import MagicMock, patch

from PyQt5.QtWidgets import QApplication, QListWidgetItem
from PyQt5.QtCore import Qt
import sys

from vitalsync_pulse.core.controllers.skill_cycle_controller import SkillCycleController
from vitalsync_pulse.modules.skill_system.skill_models import Skill, SkillCycle
from vitalsync_pulse.modules.skill_system.advanced_skills import AdvancedSkill
from vitalsync_pulse.ui.views.skill_cycle_view import SkillCycleView


class TestSkillCycleController(unittest.TestCase):
    """技能循环控制器测试类"""

    @classmethod
    def setUpClass(cls):
        """在所有测试之前设置环境"""
        # 创建QApplication实例（如果尚未创建）
        if not QApplication.instance():
            cls.app = QApplication(sys.argv)
        else:
            cls.app = QApplication.instance()

    def setUp(self):
        """每个测试前的设置"""
        # 创建模拟的视图和模型
        self.mock_view = MagicMock(spec=SkillCycleView)
        self.mock_model = MagicMock()  # 这里可以使用一个通用的Mock，因为SkillSystem可能没有明确的接口

        # 创建控制器
        self.controller = SkillCycleController(self.mock_view, self.mock_model)

        # 模拟一些技能和循环数据
        self.mock_skill = MagicMock(spec=Skill)
        self.mock_skill.id = "skill1"
        self.mock_skill.name = "测试技能"
        self.mock_skill.description = "这是一个测试技能"
        self.mock_skill.hotkey = "F1"
        self.mock_skill.cooldown = 10
        self.mock_skill.duration = 5

        self.mock_cycle = MagicMock(spec=SkillCycle)
        self.mock_cycle.id = "cycle1"
        self.mock_cycle.name = "测试循环"
        self.mock_cycle.description = "这是一个测试循环"
        self.mock_cycle.trigger_key = "F5"
        self.mock_cycle.activation_condition = "战斗中"
        self.mock_cycle.enabled = True
        self.mock_cycle.steps = []

        # 设置Skill.load和Skill.load_all的模拟返回值
        self.skill_load_patcher = patch('vitalsync_pulse.modules.skill_system.skill_models.Skill.load')
        self.mock_skill_load = self.skill_load_patcher.start()
        self.mock_skill_load.return_value = self.mock_skill

        self.skill_load_all_patcher = patch('vitalsync_pulse.modules.skill_system.skill_models.Skill.load_all')
        self.mock_skill_load_all = self.skill_load_all_patcher.start()
        self.mock_skill_load_all.return_value = {"skill1": self.mock_skill}

        # 设置SkillCycle.load和SkillCycle.load_all的模拟返回值
        self.cycle_load_patcher = patch('vitalsync_pulse.modules.skill_system.skill_models.SkillCycle.load')
        self.mock_cycle_load = self.cycle_load_patcher.start()
        self.mock_cycle_load.return_value = self.mock_cycle

        self.cycle_load_all_patcher = patch('vitalsync_pulse.modules.skill_system.skill_models.SkillCycle.load_all')
        self.mock_cycle_load_all = self.cycle_load_all_patcher.start()
        self.mock_cycle_load_all.return_value = {"cycle1": self.mock_cycle}

    def test_initialization(self):
        """测试控制器初始化"""
        # 测试视图和模型是否正确分配
        self.assertEqual(self.controller.view, self.mock_view)
        self.assertEqual(self.controller.model, self.mock_model)
        self.assertIsNone(self.controller.current_skill)
        self.assertIsNone(self.controller.current_cycle)

    def test_connect_view_model(self):
        """测试连接视图和模型"""
        # 调用连接方法
        self.controller.connect_view_model()

        # 验证视图的信号是否已连接到控制器的槽函数
        self.mock_view.skill_list.currentItemChanged.connect.assert_called()
        self.mock_view.add_skill_button.clicked.connect.assert_called()
        self.mock_view.save_skill_button.clicked.connect.assert_called()
        self.mock_view.delete_skill_button.clicked.connect.assert_called()
        self.mock_view.add_cycle_button.clicked.connect.assert_called()
        self.mock_view.save_cycle_button.clicked.connect.assert_called()
        self.mock_view.delete_cycle_button.clicked.connect.assert_called()
        self.mock_view.cycle_list.currentItemChanged.connect.assert_called()

    def test_disconnect_view_model(self):
        """测试断开视图和模型连接"""
        # 首先连接
        self.controller.connect_view_model()
        
        # 然后断开连接
        self.controller.disconnect_view_model()

        # 验证视图的信号是否已断开连接
        self.mock_view.skill_list.currentItemChanged.disconnect.assert_called()
        self.mock_view.add_skill_button.clicked.disconnect.assert_called()
        self.mock_view.save_skill_button.clicked.disconnect.assert_called()
        self.mock_view.delete_skill_button.clicked.disconnect.assert_called()
        self.mock_view.add_cycle_button.clicked.disconnect.assert_called()
        self.mock_view.save_cycle_button.clicked.disconnect.assert_called()
        self.mock_view.delete_cycle_button.clicked.disconnect.assert_called()
        self.mock_view.cycle_list.currentItemChanged.disconnect.assert_called()

    def test_load_skills(self):
        """测试加载技能列表"""
        # 调用加载技能方法
        self.controller._load_skills()

        # 验证是否清空了技能列表
        self.mock_view.skill_list.clear.assert_called_once()
        
        # 验证是否加载了所有技能
        self.mock_skill_load_all.assert_called_once()
        
        # 验证是否添加了技能项到列表
        self.mock_view.skill_list.addItem.assert_called()

    def test_load_cycles(self):
        """测试加载技能循环列表"""
        # 调用加载循环方法
        self.controller._load_cycles()

        # 验证是否清空了循环列表
        self.mock_view.cycle_list.clear.assert_called_once()
        
        # 验证是否加载了所有循环
        self.mock_cycle_load_all.assert_called_once()
        
        # 验证是否添加了循环项到列表
        self.mock_view.cycle_list.addItem.assert_called()

    def test_on_skill_selected(self):
        """测试选择技能"""
        # 创建模拟的QListWidgetItem
        mock_item = MagicMock(spec=QListWidgetItem)
        mock_item.data.return_value = "skill1"

        # 调用选择技能方法
        self.controller._on_skill_selected(mock_item, None)

        # 验证是否加载了选定的技能
        self.mock_skill_load.assert_called_once_with("skill1")
        
        # 验证是否更新了当前技能
        self.assertEqual(self.controller.current_skill, self.mock_skill)
        
        # 验证是否填充了技能表单
        self.mock_view.skill_name_edit.setText.assert_called_with(self.mock_skill.name)
        self.mock_view.skill_description_edit.setPlainText.assert_called_with(self.mock_skill.description)
        self.mock_view.skill_hotkey_edit.setText.assert_called_with(self.mock_skill.hotkey)
        self.mock_view.skill_cooldown_edit.setText.assert_called_with(str(self.mock_skill.cooldown))
        self.mock_view.skill_duration_edit.setText.assert_called_with(str(self.mock_skill.duration))

    def test_on_cycle_selected(self):
        """测试选择技能循环"""
        # 创建模拟的QListWidgetItem
        mock_item = MagicMock(spec=QListWidgetItem)
        mock_item.data.return_value = "cycle1"

        # 调用选择循环方法
        self.controller._on_cycle_selected(mock_item, None)

        # 验证是否加载了选定的循环
        self.mock_cycle_load.assert_called_once_with("cycle1")
        
        # 验证是否更新了当前循环
        self.assertEqual(self.controller.current_cycle, self.mock_cycle)
        
        # 验证是否填充了循环表单
        self.mock_view.cycle_name_edit.setText.assert_called_with(self.mock_cycle.name)
        self.mock_view.cycle_description_edit.setPlainText.assert_called_with(self.mock_cycle.description)
        self.mock_view.cycle_trigger_edit.setText.assert_called_with(self.mock_cycle.trigger_key)
        self.mock_view.cycle_condition_edit.setText.assert_called_with(self.mock_cycle.activation_condition)
        self.mock_view.cycle_enabled_checkbox.setChecked.assert_called_with(self.mock_cycle.enabled)

    def test_add_skill(self):
        """测试添加技能"""
        # 模拟Skill构造函数和save方法
        with patch('vitalsync_pulse.modules.skill_system.skill_models.Skill', autospec=True) as mock_skill_class:
            # 设置mock返回值
            mock_new_skill = MagicMock(spec=Skill)
            mock_new_skill.id = "new_skill"
            mock_skill_class.return_value = mock_new_skill
            
            # 模拟点击添加技能按钮
            self.controller._on_add_skill()
            
            # 验证是否创建了新技能
            mock_skill_class.assert_called_once_with("New Skill", "Basic skill description")
            
            # 验证是否设置了默认属性
            self.assertEqual(mock_new_skill.hotkey, "")
            self.assertEqual(mock_new_skill.cooldown, 0)
            self.assertEqual(mock_new_skill.duration, 0)
            
            # 验证是否保存了新技能
            mock_new_skill.save.assert_called_once()
            
            # 验证是否重新加载了技能列表
            self.mock_skill_load_all.assert_called()

    def test_add_cycle(self):
        """测试添加技能循环"""
        # 模拟SkillCycle构造函数和save方法
        with patch('vitalsync_pulse.modules.skill_system.skill_models.SkillCycle', autospec=True) as mock_cycle_class:
            # 设置mock返回值
            mock_new_cycle = MagicMock(spec=SkillCycle)
            mock_new_cycle.id = "new_cycle"
            mock_cycle_class.return_value = mock_new_cycle
            
            # 模拟点击添加循环按钮
            self.controller._on_add_cycle()
            
            # 验证是否创建了新循环
            mock_cycle_class.assert_called_once_with("New Skill Cycle", "Basic cycle description")
            
            # 验证是否设置了默认属性
            self.assertEqual(mock_new_cycle.trigger_key, "")
            self.assertEqual(mock_new_cycle.activation_condition, "")
            self.assertEqual(mock_new_cycle.enabled, False)
            
            # 验证是否保存了新循环
            mock_new_cycle.save.assert_called_once()
            
            # 验证是否重新加载了循环列表
            self.mock_cycle_load_all.assert_called()

    def tearDown(self):
        """每个测试后的清理"""
        # 停止所有patch
        self.skill_load_patcher.stop()
        self.skill_load_all_patcher.stop()
        self.cycle_load_patcher.stop()
        self.cycle_load_all_patcher.stop()
        
        # 断开控制器连接
        self.controller.disconnect_view_model()
        self.controller = None


if __name__ == '__main__':
    unittest.main() 