#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
测试套件

这个模块集成了所有的单元测试，可以一次性运行所有测试。
"""

import unittest

# 导入所有测试模块
from test_health_monitor_controller import TestHealthMonitorController
from test_skill_cycle_controller import TestSkillCycleController
from test_condition_trigger_controller import TestConditionTriggerController
from test_app_controller import TestAppController


def create_test_suite():
    """创建测试套件
    
    返回:
        unittest.TestSuite: 包含所有测试的测试套件
    """
    # 创建测试套件
    test_suite = unittest.TestSuite()
    
    # 添加健康监控控制器测试
    test_suite.addTest(unittest.makeSuite(TestHealthMonitorController))
    
    # 添加技能循环控制器测试
    test_suite.addTest(unittest.makeSuite(TestSkillCycleController))
    
    # 添加条件触发控制器测试
    test_suite.addTest(unittest.makeSuite(TestConditionTriggerController))
    
    # 添加应用程序控制器测试
    test_suite.addTest(unittest.makeSuite(TestAppController))
    
    return test_suite


if __name__ == "__main__":
    # 创建测试套件
    suite = create_test_suite()
    
    # 创建测试运行器
    runner = unittest.TextTestRunner(verbosity=2)
    
    # 运行测试
    runner.run(suite) 